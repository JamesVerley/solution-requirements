﻿' last edited 17/08/17
' James Verley 2017 term 3 software development sat solution

' this is the login form which allows users to set and enter a secret password and log in to the main form

Public Class PasswordForm
    Public shift = 74 ' the XOR encryption shift key
    Private Sub PasswordForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Main.LoadConfig() ' load up existing password
        If password = "" Then ' if there was no existing password,
            lblMessage.Text = "Enter a new password" ' prompt the user to make a new one
        End If
    End Sub

    ' when enter key is pressed, try logging in 
    Private Sub txtPasswordKeyPress(sender As Object, ByVal e As KeyPressEventArgs) Handles txtPassword.KeyPress
        If e.KeyChar = ChrW(Keys.Return) Then
            e.Handled = True
            btnGo_Click()
        End If
    End Sub

    Private Sub btnGo_Click() Handles btnGo.Click
        If password <> "" Then
            ' if password matches, close password form and open main form
            If txtPassword.Text = XorShift(password, shift) Then
                Main.Show()
                Close()
            Else
                lblMessage.Text = "Password Incorrect, try again"
            End If
        Else
            password = XorShift(txtPassword.Text, shift)
            Main.SaveConfig() ' this will save the new password to the config file
            lblMessage.Text = "New Password Saved, enter again to continue"
        End If
        txtPassword.Text = ""
    End Sub

    ' a sub to shift every character in a string using Xor shift by a specific value
    Public Function XorShift(ByRef str As String, ByRef shift As Integer)
        Dim tempStr As String = ""
        For i = 0 To str.Length - 1
            tempStr += ChrW(AscW(str(i)) Xor shift) ' shift character and add to new string
        Next
        Return tempStr ' return shifted string
    End Function

    Private Sub btnChangePwd_Click(sender As Object, e As EventArgs) Handles btnChangePwd.Click
        Dim tempStr As String
        Dim str = InputBox("Enter old password") ' prompts the user to enter their old password
        If str <> "" Then
            tempStr = XorShift(str, shift)
            If password = tempStr Then ' checks if its right
                str = InputBox("Enter a new password") ' then prompts the user to enter their new password
                If str <> "" Then
                    Dim FileNum As Integer = FreeFile()
                    password = XorShift(str, shift)
                    Main.SaveConfig() ' saves the new password to file
                    MessageBox.Show("Password changed!")
                Else
                    password = "" ' else, resets the password
                    MessageBox.Show("password reset!")
                End If
            Else
                MessageBox.Show("Password incorrect!")
            End If
        End If
    End Sub
End Class