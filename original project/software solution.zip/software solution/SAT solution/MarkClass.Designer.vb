﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Mark_Class
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblCriteria = New System.Windows.Forms.Label()
        Me.btnCriteriaLeft = New System.Windows.Forms.Button()
        Me.lstStudents = New System.Windows.Forms.ListBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.txtComment = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnSetAll = New System.Windows.Forms.Button()
        Me.cboPeriod = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboClass = New System.Windows.Forms.ComboBox()
        Me.cboProfile = New System.Windows.Forms.ComboBox()
        Me.dtpDate = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnCriteriaRight = New System.Windows.Forms.Button()
        Me.lblMarked = New System.Windows.Forms.Label()
        Me.nudNumber = New System.Windows.Forms.NumericUpDown()
        Me.txtTextEntry = New System.Windows.Forms.TextBox()
        Me.chkCheckEntry = New System.Windows.Forms.CheckBox()
        Me.txtMaxNum = New System.Windows.Forms.TextBox()
        Me.nudNumerator = New System.Windows.Forms.NumericUpDown()
        Me.lblDiv = New System.Windows.Forms.Label()
        Me.lblFname = New System.Windows.Forms.Label()
        Me.imgStudent = New System.Windows.Forms.PictureBox()
        Me.Students = New System.Windows.Forms.Label()
        Me.btnPrevious = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.lblMarkTitle = New System.Windows.Forms.Label()
        Me.chkIncrementStudent = New System.Windows.Forms.CheckBox()
        Me.txtDebug = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.nudNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudNumerator, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgStudent, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblCriteria
        '
        Me.lblCriteria.AutoSize = True
        Me.lblCriteria.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCriteria.Location = New System.Drawing.Point(279, 34)
        Me.lblCriteria.Name = "lblCriteria"
        Me.lblCriteria.Size = New System.Drawing.Size(77, 25)
        Me.lblCriteria.TabIndex = 35
        Me.lblCriteria.Text = "criteria"
        Me.lblCriteria.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnCriteriaLeft
        '
        Me.btnCriteriaLeft.Location = New System.Drawing.Point(220, 34)
        Me.btnCriteriaLeft.Name = "btnCriteriaLeft"
        Me.btnCriteriaLeft.Size = New System.Drawing.Size(38, 23)
        Me.btnCriteriaLeft.TabIndex = 33
        Me.btnCriteriaLeft.Text = "<"
        Me.btnCriteriaLeft.UseVisualStyleBackColor = True
        '
        'lstStudents
        '
        Me.lstStudents.FormattingEnabled = True
        Me.lstStudents.Location = New System.Drawing.Point(6, 34)
        Me.lstStudents.Name = "lstStudents"
        Me.lstStudents.Size = New System.Drawing.Size(187, 264)
        Me.lstStudents.TabIndex = 32
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.Location = New System.Drawing.Point(22, 389)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(190, 59)
        Me.btnSave.TabIndex = 31
        Me.btnSave.Text = "Done"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'txtComment
        '
        Me.txtComment.Location = New System.Drawing.Point(15, 184)
        Me.txtComment.Multiline = True
        Me.txtComment.Name = "txtComment"
        Me.txtComment.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtComment.Size = New System.Drawing.Size(200, 187)
        Me.txtComment.TabIndex = 30
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 161)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 13)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Comment"
        '
        'btnSetAll
        '
        Me.btnSetAll.Location = New System.Drawing.Point(390, 184)
        Me.btnSetAll.Name = "btnSetAll"
        Me.btnSetAll.Size = New System.Drawing.Size(73, 22)
        Me.btnSetAll.TabIndex = 26
        Me.btnSetAll.Text = "Set All"
        Me.btnSetAll.UseVisualStyleBackColor = True
        '
        'cboPeriod
        '
        Me.cboPeriod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPeriod.FormattingEnabled = True
        Me.cboPeriod.Location = New System.Drawing.Point(91, 107)
        Me.cboPeriod.Name = "cboPeriod"
        Me.cboPeriod.Size = New System.Drawing.Size(121, 21)
        Me.cboPeriod.TabIndex = 24
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 110)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Period"
        '
        'cboClass
        '
        Me.cboClass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboClass.FormattingEnabled = True
        Me.cboClass.Location = New System.Drawing.Point(91, 73)
        Me.cboClass.Name = "cboClass"
        Me.cboClass.Size = New System.Drawing.Size(121, 21)
        Me.cboClass.TabIndex = 22
        '
        'cboProfile
        '
        Me.cboProfile.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboProfile.FormattingEnabled = True
        Me.cboProfile.Location = New System.Drawing.Point(91, 38)
        Me.cboProfile.Name = "cboProfile"
        Me.cboProfile.Size = New System.Drawing.Size(121, 21)
        Me.cboProfile.TabIndex = 21
        '
        'dtpDate
        '
        Me.dtpDate.Location = New System.Drawing.Point(12, 12)
        Me.dtpDate.Name = "dtpDate"
        Me.dtpDate.Size = New System.Drawing.Size(200, 20)
        Me.dtpDate.TabIndex = 20
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 76)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Class"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(36, 13)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "Profile"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnCriteriaRight)
        Me.GroupBox1.Controls.Add(Me.lblMarked)
        Me.GroupBox1.Controls.Add(Me.nudNumber)
        Me.GroupBox1.Controls.Add(Me.txtTextEntry)
        Me.GroupBox1.Controls.Add(Me.chkCheckEntry)
        Me.GroupBox1.Controls.Add(Me.txtMaxNum)
        Me.GroupBox1.Controls.Add(Me.nudNumerator)
        Me.GroupBox1.Controls.Add(Me.lblDiv)
        Me.GroupBox1.Controls.Add(Me.lblFname)
        Me.GroupBox1.Controls.Add(Me.imgStudent)
        Me.GroupBox1.Controls.Add(Me.btnSetAll)
        Me.GroupBox1.Controls.Add(Me.Students)
        Me.GroupBox1.Controls.Add(Me.lstStudents)
        Me.GroupBox1.Controls.Add(Me.lblCriteria)
        Me.GroupBox1.Controls.Add(Me.btnCriteriaLeft)
        Me.GroupBox1.Location = New System.Drawing.Point(271, 73)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(524, 305)
        Me.GroupBox1.TabIndex = 36
        Me.GroupBox1.TabStop = False
        '
        'btnCriteriaRight
        '
        Me.btnCriteriaRight.Location = New System.Drawing.Point(449, 34)
        Me.btnCriteriaRight.Name = "btnCriteriaRight"
        Me.btnCriteriaRight.Size = New System.Drawing.Size(38, 23)
        Me.btnCriteriaRight.TabIndex = 41
        Me.btnCriteriaRight.Text = ">"
        Me.btnCriteriaRight.UseVisualStyleBackColor = True
        '
        'lblMarked
        '
        Me.lblMarked.AutoSize = True
        Me.lblMarked.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMarked.Location = New System.Drawing.Point(358, 82)
        Me.lblMarked.Name = "lblMarked"
        Me.lblMarked.Size = New System.Drawing.Size(64, 13)
        Me.lblMarked.TabIndex = 40
        Me.lblMarked.Text = "Unmarked"
        '
        'nudNumber
        '
        Me.nudNumber.Location = New System.Drawing.Point(391, 123)
        Me.nudNumber.Name = "nudNumber"
        Me.nudNumber.Size = New System.Drawing.Size(74, 20)
        Me.nudNumber.TabIndex = 39
        '
        'txtTextEntry
        '
        Me.txtTextEntry.Location = New System.Drawing.Point(353, 98)
        Me.txtTextEntry.Multiline = True
        Me.txtTextEntry.Name = "txtTextEntry"
        Me.txtTextEntry.Size = New System.Drawing.Size(134, 80)
        Me.txtTextEntry.TabIndex = 0
        '
        'chkCheckEntry
        '
        Me.chkCheckEntry.AutoSize = True
        Me.chkCheckEntry.Location = New System.Drawing.Point(390, 124)
        Me.chkCheckEntry.Name = "chkCheckEntry"
        Me.chkCheckEntry.Size = New System.Drawing.Size(42, 17)
        Me.chkCheckEntry.TabIndex = 1
        Me.chkCheckEntry.Text = "yes"
        Me.chkCheckEntry.UseVisualStyleBackColor = True
        '
        'txtMaxNum
        '
        Me.txtMaxNum.Location = New System.Drawing.Point(390, 139)
        Me.txtMaxNum.Name = "txtMaxNum"
        Me.txtMaxNum.Size = New System.Drawing.Size(75, 20)
        Me.txtMaxNum.TabIndex = 5
        '
        'nudNumerator
        '
        Me.nudNumerator.Location = New System.Drawing.Point(390, 111)
        Me.nudNumerator.Name = "nudNumerator"
        Me.nudNumerator.Size = New System.Drawing.Size(75, 20)
        Me.nudNumerator.TabIndex = 4
        '
        'lblDiv
        '
        Me.lblDiv.AutoSize = True
        Me.lblDiv.Location = New System.Drawing.Point(379, 123)
        Me.lblDiv.Name = "lblDiv"
        Me.lblDiv.Size = New System.Drawing.Size(97, 13)
        Me.lblDiv.TabIndex = 3
        Me.lblDiv.Text = "_______________"
        '
        'lblFname
        '
        Me.lblFname.AutoSize = True
        Me.lblFname.Location = New System.Drawing.Point(217, 72)
        Me.lblFname.Name = "lblFname"
        Me.lblFname.Size = New System.Drawing.Size(73, 13)
        Me.lblFname.TabIndex = 38
        Me.lblFname.Text = "student Name"
        '
        'imgStudent
        '
        Me.imgStudent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.imgStudent.Location = New System.Drawing.Point(220, 88)
        Me.imgStudent.Name = "imgStudent"
        Me.imgStudent.Size = New System.Drawing.Size(127, 99)
        Me.imgStudent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgStudent.TabIndex = 37
        Me.imgStudent.TabStop = False
        '
        'Students
        '
        Me.Students.AutoSize = True
        Me.Students.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Students.Location = New System.Drawing.Point(6, 18)
        Me.Students.Name = "Students"
        Me.Students.Size = New System.Drawing.Size(49, 13)
        Me.Students.TabIndex = 36
        Me.Students.Text = "Students"
        Me.Students.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnPrevious
        '
        Me.btnPrevious.Location = New System.Drawing.Point(271, 384)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.Size = New System.Drawing.Size(94, 23)
        Me.btnPrevious.TabIndex = 37
        Me.btnPrevious.Text = "Previous"
        Me.btnPrevious.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(701, 384)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(94, 23)
        Me.btnNext.TabIndex = 38
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'lblMarkTitle
        '
        Me.lblMarkTitle.AutoSize = True
        Me.lblMarkTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMarkTitle.Location = New System.Drawing.Point(266, 45)
        Me.lblMarkTitle.Name = "lblMarkTitle"
        Me.lblMarkTitle.Size = New System.Drawing.Size(145, 25)
        Me.lblMarkTitle.TabIndex = 40
        Me.lblMarkTitle.Text = "Class , Profile"
        Me.lblMarkTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkIncrementStudent
        '
        Me.chkIncrementStudent.AutoSize = True
        Me.chkIncrementStudent.Location = New System.Drawing.Point(469, 388)
        Me.chkIncrementStudent.Name = "chkIncrementStudent"
        Me.chkIncrementStudent.Size = New System.Drawing.Size(127, 17)
        Me.chkIncrementStudent.TabIndex = 41
        Me.chkIncrementStudent.Text = "Increment by Student"
        Me.chkIncrementStudent.UseVisualStyleBackColor = True
        '
        'txtDebug
        '
        Me.txtDebug.AllowDrop = True
        Me.txtDebug.Location = New System.Drawing.Point(801, 76)
        Me.txtDebug.Multiline = True
        Me.txtDebug.Name = "txtDebug"
        Me.txtDebug.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDebug.Size = New System.Drawing.Size(360, 329)
        Me.txtDebug.TabIndex = 42
        '
        'Mark_Class
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1173, 461)
        Me.Controls.Add(Me.txtDebug)
        Me.Controls.Add(Me.chkIncrementStudent)
        Me.Controls.Add(Me.lblMarkTitle)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btnPrevious)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.txtComment)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cboPeriod)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cboClass)
        Me.Controls.Add(Me.cboProfile)
        Me.Controls.Add(Me.dtpDate)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.MaximizeBox = False
        Me.Name = "Mark_Class"
        Me.Text = "Mark_Class"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.nudNumber, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudNumerator, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgStudent, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCriteria As Label
    Friend WithEvents btnCriteriaLeft As Button
    Friend WithEvents lstStudents As ListBox
    Friend WithEvents btnSave As Button
    Friend WithEvents txtComment As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnSetAll As Button
    Friend WithEvents cboPeriod As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents cboClass As ComboBox
    Friend WithEvents cboProfile As ComboBox
    Friend WithEvents dtpDate As DateTimePicker
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Students As Label
    Friend WithEvents btnPrevious As Button
    Friend WithEvents btnNext As Button
    Friend WithEvents lblFname As Label
    Friend WithEvents imgStudent As PictureBox
    Friend WithEvents lblMarkTitle As Label
    Friend WithEvents txtTextEntry As TextBox
    Friend WithEvents chkCheckEntry As CheckBox
    Friend WithEvents lblDiv As Label
    Friend WithEvents txtMaxNum As TextBox
    Friend WithEvents nudNumerator As NumericUpDown
    Friend WithEvents nudNumber As NumericUpDown
    Friend WithEvents lblMarked As Label
    Friend WithEvents chkIncrementStudent As CheckBox
    Friend WithEvents btnCriteriaRight As Button
    Friend WithEvents txtDebug As TextBox
End Class
