﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class LoadStudentList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtLoadedData = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkRecordSeperatorIsNewline = New System.Windows.Forms.CheckBox()
        Me.txtRecordSeperator = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.chkPropertySeperatorIsNewline = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPropertySeperator = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnRemoveProperty = New System.Windows.Forms.Button()
        Me.btnAppendProperty = New System.Windows.Forms.Button()
        Me.lstStudentProperties = New System.Windows.Forms.ListBox()
        Me.lstSelectedStudentProperties = New System.Windows.Forms.ListBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboClass = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lstLoadedStudents = New System.Windows.Forms.ListBox()
        Me.btnLoadFile = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.ofdLoadFile = New System.Windows.Forms.OpenFileDialog()
        Me.btnFormatRecords = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtLoadedData
        '
        Me.txtLoadedData.Location = New System.Drawing.Point(12, 201)
        Me.txtLoadedData.Multiline = True
        Me.txtLoadedData.Name = "txtLoadedData"
        Me.txtLoadedData.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtLoadedData.Size = New System.Drawing.Size(561, 289)
        Me.txtLoadedData.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkRecordSeperatorIsNewline)
        Me.GroupBox1.Controls.Add(Me.txtRecordSeperator)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.chkPropertySeperatorIsNewline)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtPropertySeperator)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(186, 153)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "File processing"
        '
        'chkRecordSeperatorIsNewline
        '
        Me.chkRecordSeperatorIsNewline.AutoSize = True
        Me.chkRecordSeperatorIsNewline.Location = New System.Drawing.Point(112, 77)
        Me.chkRecordSeperatorIsNewline.Name = "chkRecordSeperatorIsNewline"
        Me.chkRecordSeperatorIsNewline.Size = New System.Drawing.Size(68, 17)
        Me.chkRecordSeperatorIsNewline.TabIndex = 5
        Me.chkRecordSeperatorIsNewline.Text = "NewLine"
        Me.chkRecordSeperatorIsNewline.UseVisualStyleBackColor = True
        '
        'txtRecordSeperator
        '
        Me.txtRecordSeperator.Location = New System.Drawing.Point(6, 75)
        Me.txtRecordSeperator.Name = "txtRecordSeperator"
        Me.txtRecordSeperator.Size = New System.Drawing.Size(100, 20)
        Me.txtRecordSeperator.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(124, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Student record seperator"
        '
        'chkPropertySeperatorIsNewline
        '
        Me.chkPropertySeperatorIsNewline.AutoSize = True
        Me.chkPropertySeperatorIsNewline.Location = New System.Drawing.Point(112, 34)
        Me.chkPropertySeperatorIsNewline.Name = "chkPropertySeperatorIsNewline"
        Me.chkPropertySeperatorIsNewline.Size = New System.Drawing.Size(68, 17)
        Me.chkPropertySeperatorIsNewline.TabIndex = 2
        Me.chkPropertySeperatorIsNewline.Text = "NewLine"
        Me.chkPropertySeperatorIsNewline.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(132, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Student property separator"
        '
        'txtPropertySeperator
        '
        Me.txtPropertySeperator.Location = New System.Drawing.Point(6, 32)
        Me.txtPropertySeperator.Name = "txtPropertySeperator"
        Me.txtPropertySeperator.Size = New System.Drawing.Size(100, 20)
        Me.txtPropertySeperator.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnRemoveProperty)
        Me.GroupBox2.Controls.Add(Me.btnAppendProperty)
        Me.GroupBox2.Controls.Add(Me.lstStudentProperties)
        Me.GroupBox2.Controls.Add(Me.lstSelectedStudentProperties)
        Me.GroupBox2.Location = New System.Drawing.Point(204, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(369, 153)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Tag = ""
        Me.GroupBox2.Text = "Student Properties order"
        '
        'btnRemoveProperty
        '
        Me.btnRemoveProperty.Location = New System.Drawing.Point(139, 97)
        Me.btnRemoveProperty.Name = "btnRemoveProperty"
        Me.btnRemoveProperty.Size = New System.Drawing.Size(75, 23)
        Me.btnRemoveProperty.TabIndex = 8
        Me.btnRemoveProperty.Text = "<<"
        Me.btnRemoveProperty.UseVisualStyleBackColor = True
        '
        'btnAppendProperty
        '
        Me.btnAppendProperty.Location = New System.Drawing.Point(139, 59)
        Me.btnAppendProperty.Name = "btnAppendProperty"
        Me.btnAppendProperty.Size = New System.Drawing.Size(75, 23)
        Me.btnAppendProperty.TabIndex = 7
        Me.btnAppendProperty.Text = ">>"
        Me.btnAppendProperty.UseVisualStyleBackColor = True
        '
        'lstStudentProperties
        '
        Me.lstStudentProperties.FormattingEnabled = True
        Me.lstStudentProperties.Location = New System.Drawing.Point(6, 26)
        Me.lstStudentProperties.Name = "lstStudentProperties"
        Me.lstStudentProperties.Size = New System.Drawing.Size(117, 121)
        Me.lstStudentProperties.TabIndex = 6
        '
        'lstSelectedStudentProperties
        '
        Me.lstSelectedStudentProperties.FormattingEnabled = True
        Me.lstSelectedStudentProperties.Location = New System.Drawing.Point(229, 26)
        Me.lstSelectedStudentProperties.Name = "lstSelectedStudentProperties"
        Me.lstSelectedStudentProperties.Size = New System.Drawing.Size(122, 121)
        Me.lstSelectedStudentProperties.TabIndex = 4
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.cboClass)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.lstLoadedStudents)
        Me.GroupBox3.Location = New System.Drawing.Point(589, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(154, 449)
        Me.GroupBox3.TabIndex = 9
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Loaded records"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 406)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 13)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Class"
        '
        'cboClass
        '
        Me.cboClass.FormattingEnabled = True
        Me.cboClass.Location = New System.Drawing.Point(6, 422)
        Me.cboClass.Name = "cboClass"
        Me.cboClass.Size = New System.Drawing.Size(132, 21)
        Me.cboClass.TabIndex = 12
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Students"
        '
        'lstLoadedStudents
        '
        Me.lstLoadedStudents.FormattingEnabled = True
        Me.lstLoadedStudents.Location = New System.Drawing.Point(6, 32)
        Me.lstLoadedStudents.Name = "lstLoadedStudents"
        Me.lstLoadedStudents.Size = New System.Drawing.Size(132, 355)
        Me.lstLoadedStudents.TabIndex = 10
        '
        'btnLoadFile
        '
        Me.btnLoadFile.Location = New System.Drawing.Point(12, 174)
        Me.btnLoadFile.Name = "btnLoadFile"
        Me.btnLoadFile.Size = New System.Drawing.Size(101, 23)
        Me.btnLoadFile.TabIndex = 10
        Me.btnLoadFile.Text = "Load text/csv file"
        Me.btnLoadFile.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(589, 467)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(154, 23)
        Me.btnSave.TabIndex = 11
        Me.btnSave.Text = "Save loaded records"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'ofdLoadFile
        '
        Me.ofdLoadFile.FileName = "OpenFileDialog1"
        '
        'btnFormatRecords
        '
        Me.btnFormatRecords.Location = New System.Drawing.Point(124, 174)
        Me.btnFormatRecords.Name = "btnFormatRecords"
        Me.btnFormatRecords.Size = New System.Drawing.Size(151, 23)
        Me.btnFormatRecords.TabIndex = 12
        Me.btnFormatRecords.Text = "Format into student records"
        Me.btnFormatRecords.UseVisualStyleBackColor = True
        '
        'LoadStudentList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(753, 502)
        Me.Controls.Add(Me.btnFormatRecords)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnLoadFile)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtLoadedData)
        Me.Name = "LoadStudentList"
        Me.Text = "LoadStudentList"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtLoadedData As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents chkPropertySeperatorIsNewline As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtPropertySeperator As TextBox
    Friend WithEvents chkRecordSeperatorIsNewline As CheckBox
    Friend WithEvents txtRecordSeperator As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnRemoveProperty As Button
    Friend WithEvents btnAppendProperty As Button
    Friend WithEvents lstStudentProperties As ListBox
    Friend WithEvents lstSelectedStudentProperties As ListBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lstLoadedStudents As ListBox
    Friend WithEvents btnLoadFile As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents ofdLoadFile As OpenFileDialog
    Friend WithEvents btnFormatRecords As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents cboClass As ComboBox
End Class
