﻿' last edited 17/08/17
' James Verley 2017 term 3 software development sat solution
' aimed at p.e teachers, allow them to manage multiple class and performance records

' this module contains the code for the main form, allowing teachers to add and remove primary records,
' And view data on students, classes, profiles and entries

' variables which require constant updating:
'   maxClassRecord, maxStudent, maxProfile
'   Profile.maxCriteria
'   ClassMarking.maxStudentMarkEntry
'   ClassMarking.studentMarkEntries.maxMarkData

Public Module globals
#Region "Search/Sort"
    ' james' patented sorting module
    Sub SortById(ByRef List As Array, ByRef maxRecord As Integer)
        Dim ii As Integer
        Dim smallest As Integer
        Dim tempRecord
        For i = 0 To maxRecord
            smallest = i
            For ii = i To maxRecord
                If List(ii).id < List(i).id Then
                    smallest = ii
                End If
            Next
            tempRecord = List(i)
            List(i) = List(smallest)
            List(smallest) = tempRecord
        Next
    End Sub

    Function BinarySearchID(ByRef List As Array, ByRef maxRecord As Integer, id As Integer)
        ' returns the index of Array with the matching id, else returns -1
        If maxRecord = id Then
            Return maxRecord
        End If
        Dim currentId As Integer
        Dim range As Integer = (maxRecord + 1) / 2
        Dim clamp As Integer = 0
        Do
            currentId = List(clamp + range).id
            If currentId = id Then
                Return clamp + range
            ElseIf currentId < id Then
                clamp += range
            End If
            If range = 0 Then
                Return -1
            End If
            range = range / 2
        Loop
    End Function
#End Region
#Region "Initialise"
    Public ToolTips(99) As ToolTip ' an array of tooltips
    Public maxToolTip As Integer = -1

    ' used to add a tooltip to the the array of tooltips
    Public Sub AddToolTip(ctrl As Control, tip As String)
        maxToolTip += 1
        ToolTips(maxToolTip) = New ToolTip()
        ToolTips(maxToolTip).SetToolTip(ctrl, tip)
    End Sub

    Public password As String = "" ' will stay encrypted as program runs
    Public FileNum As Integer
    Public gender() As String = {"male", "female"}
    Public criteriaType() As String = {"Tickbox", "Number", "Fraction", "Text"}
    Public periods As String() = {"1", "1&2", "2", "3", "3&4", "4", "5", "5&6", "6"}
    Public inputFolder = "saved info/"
    Public outputFolder = inputFolder ' debug output/"
    Public classRecords(99) As ClassRecord
    Public students(9999) As Student
    Public profiles(99) As Profile
    Public classMarkings(9999) As ClassMarking
    Public item As Integer
    Public tempLine As String

    Public maxClassRecord ' max record index of 'classes', not by ClassRecord.id
    Public maxStudent ' max record index of 'students', not by Student.id
    Public maxProfile ' max record index of 'classes', not by Profile.id
    Public maxClassMarking ' max record index of 'classes', by max ClassMarking.id

    Public Structure ClassRecord
        Public id As Integer
        Public name As String
        Public year As Integer
    End Structure

    Public Structure Student
        Public id As Integer
        Public classId As Integer
        Public fname As String
        Public lname As String
        Public gender As Integer ' 0 = male, 1 = female
        Public birthdate As Date
        Public comment As String
    End Structure

    Public Structure Profile
        Public id As Integer
        Public name As String
        Public criteria() As Criteria
        Public maxCriteria As Integer
    End Structure

    Public Structure Criteria
        Public id As Integer
        Public name As String
        Public typeId As Integer
        Public max As Integer
        Public defaultValue As String
    End Structure

    Public Structure ClassMarking
        Public id As Integer
        Public entryDate As Date
        Public profileId As Integer
        Public classId As Integer
        Public periodId As Integer
        Public comment As String
        Public studentMarkEntries() As StudentMarkEntry
        Public maxStudentMarkEntry As Integer ' last index used in ClassMarking.studentMarkEntries
    End Structure

    Public Structure StudentMarkEntry
        Public studentId As Integer
        Public maxMarkData As Integer ' last index used in ClassMarking.studentMarkEntries.markData
        Public markData() As MarkDataEntry
    End Structure

    Public Structure MarkDataEntry
        Public criteriaId As Integer
        Public data As String
    End Structure

#End Region

    ' gets a date and returns the term number of that date
    Public Function DateToTerm(ByRef d As Date)
        Dim y = Date.Now.Year

        If d > Date.Parse("1/09/" & y) Then
            Return 4
        End If
        If d > Date.Parse("20/06/" & y) Then
            Return 3
        End If
        If d > Date.Parse("7/03/" & y) Then
            Return 2
        End If
        If d > Date.Parse("29/01/" & y) Then
            Return 1
        End If
    End Function
End Module

Public Class Main
    Public lstStudentIndices(999) As Integer
    Public lstEntryIndices(9999) As Integer
    Public lstStudentIndices_Report(999) As Integer
    Private dontChangeNudClassId = False

    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' load up all data from text files
        LoadStudents()
        LoadClasses()
        LoadProfiles()
        LoadEntries()

        ' display data to controls which won't change
        cboDataType_Criteria.Items.AddRange(criteriaType)
        cboPeriodSearch_ClassMarking.Items.Add("All")
        cboPeriodSearch_ClassMarking.Items.AddRange(periods)
        Mark_Class.cboPeriod.Items.AddRange(periods)
        cboTermSearch_ClassMarking.Items.AddRange({"All", "1", "2", "3", "4"})
        cboTerm_GenerateReport.Items.AddRange({"1", "2", "3", "4"})

        ' display data to all controls as necessary
        UpdateClasses()
        UpdateProfiles()
        displayEntryYears()
        UpdateEntries()
        cboYearSearch_ClassMarking.SelectedIndex = 0
        cboTermSearch_ClassMarking.SelectedIndex = 0
        cboPeriodSearch_ClassMarking.SelectedIndex = 0
        cboClassSearch_ClassMarking.SelectedIndex = 0
        entrySearchCbo_UserChanged()

        Mark_Class.cboProfile.SelectedIndex = -1
        Mark_Class.cboClass.SelectedIndex = -1
        Mark_Class.cboPeriod.SelectedIndex = 0
    End Sub

    ' for each class marking record, identify different year values. if a unique year is found, add to combobox.
    Private Sub displayEntryYears()
        Dim prevIndex As Integer
        Dim found As Boolean
        With cboYearSearch_ClassMarking
            prevIndex = .SelectedIndex
            .Items.Clear() ' reset the combobox
            .Items.Add("All") ' add the "all" option

            For item = 0 To maxClassMarking
                found = False
                For i = 1 To .Items.Count() - 1 ' loop through the year values already found
                    If CStr(classMarkings(item).entryDate.Year) = .Items(i) Then  ' has same year been found?
                        found = True ' same year identified
                    End If
                Next
                If Not found Then ' if a similar year wasn't identified
                    .Items.Add(classMarkings(item).entryDate.Year) ' add it to the combobox
                End If
            Next
            Try
                .SelectedIndex = prevIndex
            Catch ex As Exception
                .SelectedIndex = -1
            End Try
        End With
    End Sub

    Public Sub UpdateClasses()
        ' clear controls about to be filled with values
        Mark_Class.cboClass.Items.Clear()
        cboClassSearch_ClassMarking.Items.Clear()
        lstClasses_Students.Items.Clear()
        cboClassSearch_ClassMarking.Items.Add("All")
        cboClass_GenerateReport.Items.Add("All")
        Edit_students.cboClass.Items.Clear()
        LoadStudentList.cboClass.Items.Clear()

        ' add info of each classRecord to a number of controls

        For i = 0 To maxClassRecord
            With classRecords(i)
                lstClasses_Students.Items.Add(.id & " " & .name)
                Mark_Class.cboClass.Items.Add(.name)
                cboClassSearch_ClassMarking.Items.Add(.name)
                Edit_students.cboClass.Items.Add(.name)
                LoadStudentList.cboClass.Items.Add(.name)
                cboClass_GenerateReport.Items.Add(.name)
            End With
        Next
    End Sub

    Public Sub UpdateStudents()
        ' clear controls about to be filled with student info
        lstStudents_GenerateReport.Items.Clear()

        ' fill controls with student info
        lstClasses_SelectedIndexChanged()
        For i = 0 To maxStudent
            With students(i)
                lstStudents_GenerateReport.Items.Add(.id & " " & .fname & " " & .lname)
            End With
        Next
    End Sub

    Public Sub UpdateEntries()
        lstClassEntries_ClassMarking.Items.Clear()
        displayEntryYears()
        Dim increment As Integer = 0
        Dim yearMatch As Boolean
        For item = 0 To maxClassMarking

            With classMarkings(item)

                ' if cboYearSearch.Text is not "All", then test to see if selected year equals entry year
                yearMatch = False
                If cboYearSearch_ClassMarking.SelectedIndex <> 0 And cboYearSearch_ClassMarking.SelectedIndex <> -1 Then
                    If cboYearSearch_ClassMarking.Text = .entryDate.Year Then
                        yearMatch = True ' "All" is not selected, but the selected year has matched the record
                    End If
                Else
                    yearMatch = True ' "All" is selected
                End If

                ' filter the record based on items selected in comboboxes
                If (BinarySearchID(classRecords, maxClassRecord, .classId) = cboClassSearch_ClassMarking.SelectedIndex - 1 Or
                cboClassSearch_ClassMarking.SelectedIndex = 0) And
                (.periodId = cboPeriodSearch_ClassMarking.SelectedIndex - 1 Or
                cboPeriodSearch_ClassMarking.SelectedIndex = 0) And
                (cboTermSearch_ClassMarking.SelectedIndex = DateToTerm(.entryDate) Or
                cboTermSearch_ClassMarking.SelectedIndex = 0) And yearMatch Then
                    Dim tempClass As Integer = BinarySearchID(classRecords, maxClassRecord, .classId)
                    Dim tempProfile As Integer = BinarySearchID(profiles, maxProfile, .profileId)
                    If tempClass <> -1 Then
                        tempLine = classRecords(tempClass).name
                    Else
                        tempLine = "Unknown Class"
                    End If
                    tempLine += "___" & .entryDate

                    tempLine += "___"

                    If tempProfile <> -1 Then
                        tempLine += profiles(tempProfile).name
                    Else
                        tempLine += "Unknown Profile"
                    End If
                    tempLine += "___period " & periods(.periodId)

                    ' display the record in a string of details as a listbox row
                    lstClassEntries_ClassMarking.Items.Add(tempLine)

                    ' store the actual corresponding list indices of the records displayed in the listbox in a seperate integer list
                    lstEntryIndices(increment) = item
                End If
            End With
        Next
    End Sub

    Public Sub UpdateProfiles()
        ' clear controls about to be filled with values
        Mark_Class.cboProfile.Items.Clear()
        Dim profiles_Criteria As Integer = lstProfiles_Criteria.SelectedIndex
        lstProfiles_Criteria.Items.Clear()

        ' fill all relevant profile controls with rows of profile details
        For item = 0 To maxProfile
            tempLine = profiles(item).name
            Mark_Class.cboProfile.Items.Add(tempLine)
            lstProfiles_Criteria.Items.Add(profiles(item).id & " " & tempLine)
        Next
        If maxProfile >= profiles_Criteria Then
            lstProfiles_Criteria.SelectedIndex = profiles_Criteria ' deselect currently selected profile record of the profile listbox
        End If
    End Sub

    Private Sub btnSaveClass_Students_Click(sender As Object, e As EventArgs) Handles btnSaveClass_Students.Click
        ' only accept feasible values for year of class
        If Not (IsNumeric(txtClassYear_Students.Text) And txtClassYear_Students.Text.Length = 4) Then
            MessageBox.Show("Please enter a valid year")
            Return
        End If

        ' attempt to find another record of the same id
        item = nudClassId_Students.Value
        Dim IdMatch As Integer = BinarySearchID(classRecords, maxClassRecord, item)

        ' if matching id found, update existing record, else create a new one
        If IdMatch <> -1 Then
            item = IdMatch
        Else
            maxClassRecord += 1
            item = maxClassRecord
        End If

        ' assign entered values
        classRecords(item).id = nudClassId_Students.Value
        classRecords(item).name = txtClassName_Students.Text
        classRecords(item).year = txtClassYear_Students.Text

        ' sort records and update
        SortById(classRecords, maxClassRecord)
        UpdateClasses()
    End Sub

    Private Sub btnDeleteClass_Students_Click(sender As Object, e As EventArgs) Handles btnDeleteClass_Students.Click
        item = lstClasses_Students.SelectedIndex ' get the index of the record being deleted
        If item <> -1 Then ' if an item is actually selected
            classRecords(item) = classRecords(maxClassRecord) ' replace selected record with last record
            maxClassRecord -= 1 ' delete the last record (can only delete the last one)
            SortById(classRecords, maxClassRecord) ' sort records so that the selected record is replaced with adjacent one and so on
            UpdateClasses() ' apply changes to interface
            lstClasses_SelectedIndexChanged()
        End If
    End Sub

    Private Sub btnDeleteStudent_Students_Click(sender As Object, e As EventArgs) Handles btnDeleteStudent_Students.Click
        item = lstStudents_Students.SelectedIndex ' get the index of the record being deleted
        If item <> -1 Then ' if an item is actually selected
            students(lstStudentIndices(item)) = students(maxStudent) ' replace selected record with last record
            maxStudent -= 1 ' delete the last record (can only delete the last one)
            SortById(students, maxStudent) ' sort records so that the selected record is replaced with adjacent one and so on

            UpdateStudents() ' apply changes to interface
        End If
    End Sub

    Private Sub EditStudents(sender As Object, e As EventArgs) _
        Handles lstStudents_Students.DoubleClick, btnEdit_Students.Click ' either double click record or click edit button
        item = lstStudents_Students.SelectedIndex ' get the index of the selected record
        If item <> -1 Then ' if an item is actually selected
            Edit_students.EditStudent(students(lstStudentIndices(item)).id) ' prepare the edit students dialog with info based on a student id
            Edit_students.ShowDialog() ' open the edit students form as a dialog
        End If
    End Sub

    Private Sub btnNew_Students_Click(sender As Object, e As EventArgs) Handles btnNew_Students.Click
        Edit_students.NewStudent() ' prepare the edit students dialog with info based on non-existing student
        If maxClassMarking <> -1 Then
            Edit_students.cboClass.Text = classRecords(lstClasses_Students.SelectedIndex).name ' set selected class of dialog to selected class in the students tab
        Else
            Edit_students.cboClass.Text = ""
        End If
        Edit_students.ShowDialog() ' open the students form as dialog
    End Sub

    ' when load list is clicked, show the form as a dialog
    Private Sub btnLoadList_Students_Click() Handles btnLoadList_Students.Click
        LoadStudentList.ShowDialog()
    End Sub

    ' create a new profile record containing permanent "attendance" criteria
    Private Sub btnNewProfile_Criteria_Click(sender As Object, e As EventArgs) Handles btnNewProfile_Criteria.Click
        If maxProfile > 98 Then ' prevent the user from creating more than 100 profiles
            MessageBox.Show("maximum number of profiles is 100!")
            Return
        End If
        maxProfile += 1
        With profiles(maxProfile)
            ' always make the id 1 higher than that of last existing one
            If maxProfile > 0 Then
                .id = profiles(maxProfile - 1).id + 1
            Else
                .id = 0
            End If

            ' set default values of new profile
            .name = "New Profile"
            .maxCriteria = 0
            ReDim .criteria(19) ' dimension criteria
            With .criteria(0)
                .id = 0
                .name = "attendance"
                .typeId = 0
                .max = 0
                .defaultValue = 1
            End With
        End With
        ' apply changes to interface
        UpdateProfiles()
        lstProfiles_Criteria.SelectedIndex = maxProfile
        lstCriteria_Criteria.SelectedIndex = 0
    End Sub

    Private Sub btnDeleteProfile_Click(sender As Object, e As EventArgs) Handles btnDeleteProfile_Criteria.Click
        ' replace selected record with last one
        profiles(lstProfiles_Criteria.SelectedIndex) = profiles(maxProfile)
        lstProfiles_Criteria.SelectedIndex = -1
        ' delete last record and sort by id
        maxProfile -= 1
        SortById(profiles, maxProfile)
        UpdateProfiles()
    End Sub

    ' add a new criteria record to selected profile
    Private Sub btnSave_Criteria_Click(sender As Object, e As EventArgs) Handles btnSave_Criteria.Click
        item = lstProfiles_Criteria.SelectedIndex ' get index of selected profile
        If item = -1 Then ' exit if no item is selected
            Return
        End If
        Dim tempId As Integer = item ' preserve value of item in another variable before it changes
        With profiles(item)
            ' try to find a match for selected criteria, else just create a new one
            Dim criteriaIndex = BinarySearchID(.criteria, .maxCriteria, nudId_Criteria.Value)
            If criteriaIndex = -1 Then
                .maxCriteria += 1
                criteriaIndex = .maxCriteria
            End If

            ' save criteria properties
            With .criteria(criteriaIndex)
                .id = nudId_Criteria.Value
                .name = txtCriteriaName_Criteria.Text
                .typeId = cboDataType_Criteria.SelectedIndex
                Select Case .typeId
                    Case 0
                        .defaultValue = chkDefault_Criteria.Checked
                    Case 1
                        .defaultValue = nudDefault_Criteria.Value
                    Case 2
                        .defaultValue = nudDefault_Criteria.Value
                    Case 3
                        .defaultValue = txtDefault_Criteria.Text
                End Select
                .max = CInt(nudMax_Criteria.Text)
            End With

            ' sort and update criteria to interface
            SortById(.criteria, .maxCriteria)
            UpdateProfiles()
            lstProfiles_Criteria.SelectedIndex = tempId
            ' nudId_Criteria.Value = profiles(item).criteria(lstCriteria_Criteria.SelectedIndex).id
        End With
    End Sub

    ' add a new class with default settings
    Private Sub btnNewClass_Students_Click(sender As Object, e As EventArgs) Handles btnNewClass_Students.Click
        txtClassName_Students.Text = "New Class"
        txtClassYear_Students.Text = Date.Now.Year
        nudClassId_Students.Value = maxClassRecord + 1
        btnSaveClass_Students.PerformClick()
    End Sub

    ' delete selected criteria if a profile is selected, sort and update interface
    Private Sub btnDeleteCriteria_Criteria_Click(sender As Object, e As EventArgs) Handles btnDeleteCriteria_Criteria.Click
        item = lstProfiles_Criteria.SelectedIndex
        If item <> -1 Then
            If profiles(item).criteria(lstCriteria_Criteria.SelectedIndex).id <> 0 Then
                With profiles(item)
                    ' replace selected record of profiles criteria with the last one then 'delete' last record
                    .criteria(lstCriteria_Criteria.SelectedIndex) = .criteria(.maxCriteria)
                    .maxCriteria -= 1

                    If lstProfiles_Criteria.Items.Count > 1 Then
                        lstCriteria_Criteria.SelectedIndex = -1
                    End If
                    SortById(.criteria, .maxCriteria)
                End With
                lstProfiles_Criteria_SelectedIndexChanged()
            End If
        End If
    End Sub

    ' save a new criteria record with default properties
    Private Sub btnAddCriteria_Criteria_Click(sender As Object, e As EventArgs) Handles btnAddCriteria_Criteria.Click
        Dim newIndex As Integer
        ' find a match for value of nudId in profiles()
        With profiles(lstProfiles_Criteria.SelectedIndex)
            If .maxCriteria > 18 Then
                MessageBox.Show("Maximum criteria per profile is 20!")
                Return
            End If
            If .maxCriteria > -1 Then
                newIndex = .criteria(.maxCriteria).id + 1
            Else
                newIndex = 0
            End If
            .maxCriteria += 1

            With .criteria(.maxCriteria)
                .id = newIndex
                .name = "New Criteria"
                .max = 5
                .typeId = 2
                .defaultValue = 3
            End With
        End With
        lstProfiles_Criteria_SelectedIndexChanged()
    End Sub

    ' delete a class marking record and update interface
    Private Sub btnDelete_ClassMarking_Click(sender As Object, e As EventArgs) Handles btnDelete_ClassMarking.Click
        item = lstEntryIndices(lstClassEntries_ClassMarking.SelectedIndex)
        classMarkings(item) = classMarkings(maxClassMarking)
        maxClassMarking -= 1
        SortById(classMarkings, maxClassMarking)
        UpdateEntries()
    End Sub

    ' make sure relevant records exist, then run the class marking dialog
    Private Sub btnEdit_ClassMarking_Click(sender As Object, e As EventArgs) Handles btnEdit_ClassMarking.Click, lstClassEntries_ClassMarking.DoubleClick
        If maxProfile = -1 Then ' prevent the user from attempting to mark without a profile
            MessageBox.Show("please create a marking profile first!")
            Return
        End If
        If maxClassRecord = -1 Then ' make sure the user has a class to mark
            MessageBox.Show("please create a class with students first!")
            Return
        End If
        If lstClassEntries_ClassMarking.SelectedIndex <> -1 Then ' if 
            Mark_Class.EditEntry(lstEntryIndices(lstClassEntries_ClassMarking.SelectedIndex))
            Mark_Class.ShowDialog()
        End If
    End Sub

#Region "SelectedIndex/Value Changed"
    ' display marking info and analysis based on newly selected record
    Private Sub lstClassEntries_ClassMarking_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstClassEntries_ClassMarking.SelectedIndexChanged
        If lstClassEntries_ClassMarking.SelectedIndex <> -1 Then
            item = lstEntryIndices(lstClassEntries_ClassMarking.SelectedIndex)
        Else
            Return
        End If

        ' display details of selected entry beside listbox
        Dim attendance As Integer = 0
        Dim NoStudents As Integer = 0
        With classMarkings(lstEntryIndices(lstClassEntries_ClassMarking.SelectedIndex))
            For i = 0 To .maxStudentMarkEntry
                Try
                    If CBool(.studentMarkEntries(i).markData(0).data) Then
                        attendance += 1
                    End If
                Catch
                End Try
            Next

            ' display basic details of record
            lblDate_ClassMarking.Text = .entryDate
            lblClass_ClassMarking.Text = classRecords(BinarySearchID(classRecords, maxClassRecord, .classId)).name
            lblPeriod_ClassMarking.Text = periods(.periodId)
            lblProfile_ClassMarking.Text = profiles(BinarySearchID(profiles, maxProfile, .profileId)).name

            ' calculate the number of students in the class of the record
            For student = 0 To maxStudent
                If students(student).classId = .classId Then
                    NoStudents += 1
                End If
            Next
            ' display mark and attendance rate
            lblStudentsMarked_CLassMarking.Text = .maxStudentMarkEntry + 1 & " / " & NoStudents
            lblAttendance_ClassMarking.Text = attendance
        End With
    End Sub

    Private Sub cboDataType_Criteria_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDataType_Criteria.SelectedIndexChanged
        ' set all 'default value' controls to be invisible
        txtDefault_Criteria.Hide()
        chkDefault_Criteria.Hide()
        cboDefault_Criteria.Hide()
        nudDefault_Criteria.Hide()
        nudMax_Criteria.Enabled = True
        ' show the default value control relevant to the selected type
        Select Case cboDataType_Criteria.SelectedIndex
            Case 0 ' tickbox
                nudMax_Criteria.Enabled = False
                chkDefault_Criteria.Show()
            Case 1 To 2 ' number / fraction
                nudDefault_Criteria.Show()
            Case 3 ' text
                txtDefault_Criteria.Show()
        End Select
    End Sub

    Private Sub lstProfiles_Criteria_SelectedIndexChanged() Handles lstProfiles_Criteria.SelectedIndexChanged
        ' refresh contents of listbox which represents selected item's values

        'clear listbox and re-add all profiles
        lstCriteria_Criteria.Items.Clear()
        If lstProfiles_Criteria.SelectedIndex > -1 And profiles.Length > 0 Then
            nudId_Criteria.Value = profiles(lstProfiles_Criteria.SelectedIndex).id
            txtProfileName_Criteria.Text = profiles(lstProfiles_Criteria.SelectedIndex).name
            With profiles(lstProfiles_Criteria.SelectedIndex)
                For ii = 0 To .maxCriteria
                    lstCriteria_Criteria.Items.Add(.criteria(ii).id & " " & .criteria(ii).name) ' add criteria to listbox
                Next
            End With
        Else
            txtProfileName_Criteria.Text = ""
            lstCriteria_Criteria.SelectedIndex = -1
        End If
        If lstCriteria_Criteria.Items.Count > 0 Then
            lstCriteria_Criteria.SelectedIndex = 0
        End If
    End Sub

    ' refresh selected criteria properties to interface
    Private Sub lstCriteria_Criteria_SelectedIndexChanged() Handles lstCriteria_Criteria.SelectedIndexChanged
        If lstCriteria_Criteria.SelectedIndex = -1 Then
            Return
        End If

        ' assign user-modified properties to the record in memory
        With profiles(lstProfiles_Criteria.SelectedIndex).criteria(lstCriteria_Criteria.SelectedIndex)
            nudId_Criteria.Value = .id
            If .id = 0 Then
                txtCriteriaName_Criteria.Enabled = False
            Else
                txtCriteriaName_Criteria.Enabled = True
            End If
            txtCriteriaName_Criteria.Text = .name
            cboDataType_Criteria.SelectedIndex = .typeId
            Select Case .typeId
                Case 0
                    chkDefault_Criteria.Checked = .defaultValue
                Case 1 To 2
                    nudDefault_Criteria.Value = .defaultValue
                Case 3
                    txtDefault_Criteria.Text = .defaultValue
            End Select
            nudMax_Criteria.Text = .max
        End With
    End Sub

    ' update properties of newly selected student record to interface
    Public Sub lstStudents_Students_SelectedIndexChanged() Handles lstStudents_Students.SelectedIndexChanged
        lstStudentClasses_Students.Items.Clear()
        item = lstStudents_Students.SelectedIndex
        If item > -1 Then
            With students(lstStudentIndices(item))
                lblName_Students.Text = .fname & " " & .lname
                lblAge_Students.Text = Date.Now.Year - .birthdate.Year
                lblGender_Students.Text = gender(.gender)
                txtComment_Students.Text = .comment
                imgIcon_Students.ImageLocation = inputFolder & "student icons/" & .id & ".png"
                If .classId > -1 Then
                    lstStudentClasses_Students.Items.Add(.classId & " " & classRecords(.classId).name)
                Else
                    lstStudentClasses_Students.Items.Add("None")
                End If
            End With
        End If
    End Sub

    ' update the selectedindex of the class listbox ONLY when the user changes the nud
    Private Sub nudClassId_Students_ValueChanged(sender As Object, e As EventArgs) Handles nudClassId_Students.ValueChanged
        If dontChangeNudClassId = True Then
            dontChangeNudClassId = False
            Return
        End If
        item = BinarySearchID(classRecords, maxClassRecord, nudClassId_Students.Value)
        If item <> -1 Then
            lstClasses_Students.SetSelected(item, True)
        End If
    End Sub

    ' change selectedindex of criteria listbox if a match is found for criteria
    Private Sub nudIdCriteria_ValueChanged(sender As Object, e As EventArgs) Handles nudId_Criteria.ValueChanged
        If lstProfiles_Criteria.SelectedIndex <> -1 Then
            item = BinarySearchID(profiles(lstProfiles_Criteria.SelectedIndex).criteria,
                      profiles(lstProfiles_Criteria.SelectedIndex).maxCriteria,
                      nudId_Criteria.Value)
            Try
                lstCriteria_Criteria.SetSelected(item, True)
            Catch
            End Try
        End If
    End Sub

    Private Sub entrySearchCbo_UserChanged() Handles _
    cboPeriodSearch_ClassMarking.SelectionChangeCommitted, cboClassSearch_ClassMarking.SelectionChangeCommitted,
    cboYearSearch_ClassMarking.SelectionChangeCommitted, cboTermSearch_ClassMarking.SelectionChangeCommitted
        UpdateEntries() ' this code runs whenever any entry filter combobox value is changed by the user
    End Sub
#End Region

#Region "loading/saving"

    ' saves all data in memory which needs to be saved
    Private Sub SaveAll() Handles MyBase.FormClosing
        SaveClasses()
        SaveStudents()
        SaveProfiles()
        SaveEntries()
        SaveConfig()
    End Sub

    Private Sub LoadStudents()
        ' opens the students file and loads records
        Dim FileNum As Integer = FreeFile()
        FileOpen(FileNum, inputFolder & "students.txt", OpenMode.Input) ' open file
        Do Until EOF(FileNum)
            tempLine = LineInput(FileNum)
            With students(item)
                ' assign tempLine to variables
                .id = tempLine
                .classId = LineInput(FileNum)
                .fname = LineInput(FileNum)
                .lname = LineInput(FileNum)
                .gender = CInt(LineInput(FileNum))
                .birthdate = CDate(LineInput(FileNum))
                .comment = LineInput(FileNum).Replace("/n\", vbCrLf)
                item += 1
            End With
        Loop
        maxStudent = item - 1
        item = 0
        FileClose(FileNum) ' close the file
    End Sub

    Private Sub LoadClasses()
        ' opens the classes file and loads records
        Dim FileNum As Integer = FreeFile()
        Try
            FileOpen(FileNum, inputFolder & "classes.txt", OpenMode.Input) ' open file
            item = 0
            Do Until EOF(FileNum)
                tempLine = LineInput(FileNum)
                If tempLine <> "" Then
                    With classRecords(item)
                        ' assign tempLine to variables
                        .id = tempLine
                        .name = LineInput(FileNum)
                        .year = LineInput(FileNum)
                        item += 1
                    End With
                End If
            Loop
            maxClassRecord = item - 1
            item = 0
            FileClose(FileNum) ' close the file
        Catch
            maxClassRecord = -1
        End Try
    End Sub

    Private Sub LoadProfiles()
        ' opens the profiles file and loads records
        Dim FileNum As Integer = FreeFile()
        Try
            FileOpen(FileNum, inputFolder & "profiles.txt", OpenMode.Input) ' open file
        Catch ex As Exception
            FileOpen(FileNum, inputFolder & "profiles.txt", OpenMode.Output)
            FileClose(FileNum)
            Return
        End Try
        Do Until EOF(FileNum)
            tempLine = LineInput(FileNum)
            With profiles(item)
                ' assign tempLine to variables
                .id = tempLine
                .name = LineInput(FileNum)

                LineInput(FileNum)
                tempLine = LineInput(FileNum)

                ' redefine profile of item for criteria to length 20. cannot declare structure member arrays with initial size
                ReDim .criteria(19)

                Dim criteriaLine(4) As String
                Dim ii As Integer = 0
                While tempLine <> "]"
                    criteriaLine = tempLine.Split(",")
                    .criteria(ii).id = CInt(criteriaLine(0))
                    .criteria(ii).name = criteriaLine(1)
                    .criteria(ii).typeId = CInt(criteriaLine(2))
                    If criteriaLine(3) <> "-" Then
                        .criteria(ii).max = CInt(criteriaLine(3))
                    End If

                    Select Case .criteria(ii).typeId
                        Case 0
                            .criteria(ii).defaultValue = CBool(criteriaLine(4))
                        Case 1 To 2
                            .criteria(ii).defaultValue = CInt(criteriaLine(4))
                        Case Else
                            .criteria(ii).defaultValue = criteriaLine(4)
                    End Select
                    tempLine = LineInput(FileNum)
                    ii += 1
                End While
                .maxCriteria = ii - 1
            End With
            item += 1
        Loop
        maxProfile = item - 1
        item = 0
        FileClose(FileNum) ' close the file
    End Sub

    Private Sub LoadEntries()
        ' opens the profiles file and loads records
        Dim FileNum As Integer = FreeFile()
        Try
            FileOpen(FileNum, inputFolder & "entries.txt", OpenMode.Input) ' open file
        Catch
            Return
        End Try

        Do Until EOF(FileNum) ' load up all mark entry records until end of file reached
            With classMarkings(item)
                ' assign tempLine to variables
                .id = LineInput(FileNum)
                .entryDate = LineInput(FileNum)
                .profileId = LineInput(FileNum)
                .classId = LineInput(FileNum)
                .periodId = LineInput(FileNum)
                .comment = LineInput(FileNum)

                LineInput(FileNum)
                tempLine = LineInput(FileNum)

                ' redefine entry of item for data to length 99. cannot declare structure member arrays with initial size
                ReDim .studentMarkEntries(99)
                Dim dataLine(19) As String
                Dim studentId As Integer
                Dim ii As Integer = 0
                While tempLine <> "]" ' load up each student mark entry by line until the end character is reached
                    ReDim .studentMarkEntries(ii).markData(19)
                    dataLine = tempLine.Split("=")
                    studentId = CInt(dataLine(0))
                    dataLine = dataLine(1).Split(",")

                    .studentMarkEntries(ii).studentId = studentId
                    Dim i As Integer
                    For i = 0 To dataLine.Length - 1
                        .studentMarkEntries(ii).markData(i).criteriaId = CInt(CStr(dataLine(i)(0)))
                        .studentMarkEntries(ii).markData(i).data = dataLine(i).Split(" ")(1)
                    Next
                    .studentMarkEntries(ii).maxMarkData = i - 1

                    tempLine = LineInput(FileNum)
                    ii += 1

                End While
                .maxStudentMarkEntry = ii - 1
            End With
            item += 1
        Loop
        maxClassMarking = item - 1
        item = 0
        FileClose(FileNum) ' close the file
    End Sub

    Private Sub SaveStudents()
        ' opens the students file and loads records
        Dim FileNum As Integer = FreeFile()
        FileOpen(FileNum, outputFolder & "students.txt", OpenMode.Output) ' open file
        For item = 0 To maxStudent
            With students(item)
                ' assign tempLine to variables
                PrintLine(FileNum, CStr(.id))
                PrintLine(FileNum, CStr(.classId))
                PrintLine(FileNum, .fname)
                PrintLine(FileNum, .lname)
                PrintLine(FileNum, CStr(.gender))
                PrintLine(FileNum, CStr(.birthdate))
                PrintLine(FileNum, .comment.Replace(vbCrLf, "/n\"))
            End With
        Next
        FileClose(FileNum) ' close the file
    End Sub

    Private Sub SaveClasses()
        ' opens the classes file and loads records
        Dim FileNum As Integer = FreeFile()
        FileOpen(FileNum, outputFolder & "classes.txt", OpenMode.Output) ' open file
        For item = 0 To maxClassRecord
            With classRecords(item)
                PrintLine(FileNum, CStr(.id))
                PrintLine(FileNum, .name)
                PrintLine(FileNum, CStr(.year))
            End With
        Next
        FileClose(FileNum) ' close the file
    End Sub

    Private Sub SaveProfiles()
        ' opens the students file and loads records
        Dim FileNum As Integer = FreeFile()
        FileOpen(FileNum, outputFolder & "profiles.txt", OpenMode.Output) ' open file
        For item = 0 To maxProfile
            With profiles(item)
                ' save properties tempLine by tempLine to text file
                PrintLine(FileNum, CStr(.id))
                PrintLine(FileNum, .name)
                PrintLine(FileNum, "[")
                For i = 0 To .maxCriteria ' save criteria, one line each
                    With .criteria(i)
                        PrintLine(FileNum, .id & "," & .name & "," & .typeId & "," & .max & "," & .defaultValue)
                    End With
                Next
                PrintLine(FileNum, "]")
            End With
        Next
        FileClose(FileNum) ' close the file
    End Sub

    Private Sub SaveEntries()
        ' opens the entries file and saves records

        Dim FileNum As Integer = FreeFile()
        FileOpen(FileNum, outputFolder & "entries.txt", OpenMode.Output) ' open file
        For item = 0 To maxClassMarking
            With classMarkings(item)
                ' save properties tempLine by tempLine to text file
                PrintLine(FileNum, CStr(.id))
                PrintLine(FileNum, CStr(.entryDate))
                PrintLine(FileNum, CStr(.profileId))
                PrintLine(FileNum, CStr(.classId))
                PrintLine(FileNum, CStr(.periodId))
                PrintLine(FileNum, .comment)
                PrintLine(FileNum, "[")

                For i = 0 To .maxStudentMarkEntry ' save student mark entries, one line each
                    With .studentMarkEntries(i)
                        tempLine = .studentId & "="
                        For ii = 0 To .maxMarkData - 1
                            tempLine += .markData(ii).criteriaId & " " & .markData(ii).data & ","
                        Next
                        tempLine += .markData(.maxMarkData).criteriaId & " " & .markData(.maxMarkData).data

                        PrintLine(FileNum, tempLine)
                    End With
                Next
                PrintLine(FileNum, "]")
            End With
        Next
        FileClose(FileNum) ' close the file
    End Sub

    Public Sub SaveConfig()
        FileNum = FreeFile() ' find a spare filenumber
        FileOpen(FileNum, inputFolder & "config.txt", OpenMode.Output) ' open config.txt
        PrintLine(FileNum, password) ' save user password (XOR encrypted)
        PrintLine(FileNum, Mark_Class.chkIncrementStudent.Checked) ' save the increment student option
        FileClose(FileNum) ' close the file
    End Sub

    Public Sub LoadConfig()
        FileNum = FreeFile() ' find a spare filenumber
        Try
            FileOpen(FileNum, inputFolder & "config.txt", OpenMode.Input) ' open file
            password = LineInput(FileNum) ' load user password
            Mark_Class.chkIncrementStudent.Checked = CBool(LineInput(FileNum)) ' load the increment student option
        Catch
        End Try
        FileClose(FileNum) ' close the file
    End Sub
#End Region

    ' when the user clicks the mark a class option, create a new temporary entry and show the dialog
    Private Sub btnMarkClass_ClassMarking_Click(sender As Object, e As EventArgs) Handles btnMarkClass_ClassMarking.Click
        If maxProfile = -1 Then
            MessageBox.Show("please create a marking profile first!")
            Return ' return if no class exists
        End If
        Mark_Class.NewEntry()
        Mark_Class.ShowDialog()
    End Sub

    ' resets all the criteria control data in the profiles tab
    Private Sub btnResetCriteria_Criteria_Click(sender As Object, e As EventArgs) Handles btnResetCriteria_Criteria.Click
        cboDefault_Criteria.SelectedIndex = -1
        txtCriteriaName_Criteria.Text = ""
        nudMax_Criteria.Value = 0
        txtDefault_Criteria.Text = ""
        nudDefault_Criteria.Value = 0
        chkDefault_Criteria.Checked = False
    End Sub

    ' on leaving the nudDefault box, increase the maximum if exceeded by the default
    Private Sub nudDefault_Criteria_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles nudDefault_Criteria.Validating, nudMax_Criteria.Validating
        If nudDefault_Criteria.Value > nudMax_Criteria.Value Then
            nudMax_Criteria.Value = nudDefault_Criteria.Value
        End If
    End Sub

    ' saves the name of the selected profile when the textbox is left
    Private Sub txtProfileName_Criteria_Leave(sender As Object, e As EventArgs) Handles txtProfileName_Criteria.Leave
        If lstProfiles_Criteria.SelectedIndex <> -1 Then
            profiles(lstProfiles_Criteria.SelectedIndex).name = txtProfileName_Criteria.Text
            UpdateProfiles()
        End If
    End Sub

    Private Sub lstClasses_SelectedIndexChanged() Handles lstClasses_Students.SelectedIndexChanged
        item = lstClasses_Students.SelectedIndex

        ' fills the student listbox with records that match the class selected
        lstStudents_Students.Items.Clear()
        Dim increment As Integer = 0
        If item = -1 Then
            txtClassName_Students.Text = ""
            txtClassYear_Students.Text = ""
            dontChangeNudClassId = True
            nudClassId_Students.Text = maxClassRecord + 1

            ' display all students
            lblClassFilter.Text = "From all classes"
            For i = 0 To maxStudent
                lstStudents_Students.Items.Add(students(i).fname & " " & students(i).lname)
                lstStudentIndices(increment) = i
                increment += 1
            Next
        Else
            ' display selected class record details
            txtClassName_Students.Text = classRecords(item).name
            txtClassYear_Students.Text = classRecords(item).year
            dontChangeNudClassId = True
            nudClassId_Students.Text = classRecords(item).id

            ' display students based on selected class
            lblClassFilter.Text = "From " & classRecords(item).name
            For i = 0 To maxStudent
                If students(i).classId = classRecords(item).id Then
                    lstStudents_Students.Items.Add(students(i).fname & " " & students(i).lname)
                    lstStudentIndices(increment) = i
                    increment += 1
                End If
            Next
        End If
    End Sub

    Private Sub btnDeselect_Students_Click(sender As Object, e As EventArgs) Handles btnDeselect_Students.Click
        lstClasses_Students.SelectedIndex = -1
    End Sub

    Private Sub cboClass_GenerateReport_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboClass_GenerateReport.SelectedIndexChanged
        Dim increment As Integer = 0
        lstStudents_GenerateReport.Items.Clear()
        item = cboClass_GenerateReport.SelectedIndex
        Dim classId As Integer = -1
        If item <> 0 Then
            classId = classRecords(item - 1).id
        End If
        For i = 0 To maxStudent
            If item = 0 Or students(i).classId = classId Then
                lstStudents_GenerateReport.Items.Add(students(i).fname & " " & students(i).lname)
                lstStudentIndices_Report(increment) = i
                increment += 1
            End If
        Next
    End Sub

    Private Sub btnGenerateReport_Click(sender As Object, e As EventArgs) Handles btnGenerateReport.Click
        If cboTerm_GenerateReport.SelectedIndex = -1 Then ' make sure the user selects a term
            MessageBox.Show("Please select a term")
            Return
        End If
        If lstStudents_GenerateReport.SelectedIndex = -1 Then ' make sure the user selects a student
            MessageBox.Show("Please select a student")
            Return
        End If

        ' local variables to store inputs and results
        Dim selectedStudent As Integer = lstStudentIndices_Report(lstStudents_GenerateReport.SelectedIndex)
        Dim totalMarkings As Integer = 0
        Dim attendance As Integer = 0

        ' Student name, term
        lblProgressTitle_GenerateReport.Text = students(selectedStudent).fname & " " & students(selectedStudent).lname & ", Term " & cboTerm_GenerateReport.Text

        ' calculate totalmarkings and attendance

        ' for each classmarking with matching classid:
        ' for each studentmarkentry with matching studentid:
        ' add 1 onto totalMarkings
        ' add 1 onto attendance if .markdata(0) is true

        For classMarking = 0 To maxClassMarking
            With classMarkings(classMarking)
                If .classId = students(selectedStudent).classId Then
                    For markEntry = 0 To .maxStudentMarkEntry
                        If .studentMarkEntries(markEntry).studentId = students(selectedStudent).id Then
                            totalMarkings += 1
                            If CBool(.studentMarkEntries(markEntry).markData(0).data) Then
                                attendance += 1
                            End If
                            markEntry = .maxStudentMarkEntry + 1 ' exit loop
                        End If
                    Next
                End If
            End With
        Next

        ' display summary results
        lblTotalSessions_GenerateReport.Text = totalMarkings
        lblTotalAttended_GenerateReport.Text = attendance
        If totalMarkings > 0 Then
            lblAttendance_GenerateReport.Text = attendance / totalMarkings * 100 & "%"
        Else
            lblAttendance_GenerateReport.Text = "0%"
        End If
    End Sub

    Private Sub btnExportSpreadsheet_GenerateReport_Click(sender As Object, e As EventArgs) Handles btnExportSpreadsheet_GenerateReport.Click
        If cboTerm_GenerateReport.SelectedIndex <> -1 And lstStudents_GenerateReport.SelectedIndex <> -1 Then ' make sure the user selects a student

            'the filename (will show in the filename box)
            sfdSaveFile.FileName = ""
            'the title of the window to open a file
            sfdSaveFile.Title = "Save File..."
            'the filetypes to allow the user to view
            sfdSaveFile.Filter = "spreadsheet|*.csv"
            'now to open the dialog and check if OK has been pressed
            If sfdSaveFile.ShowDialog <> DialogResult.OK Then
                Return
            End If

            Dim tempStr As String = "entryDate,attendance"
            Dim selectedStudent As Integer = lstStudentIndices_Report(lstStudents_GenerateReport.SelectedIndex)
            ' Student name, term

            lblProgressTitle_GenerateReport.Text = students(selectedStudent).fname & " " & students(selectedStudent).lname & ", Term " & cboTerm_GenerateReport.Text

            ' calculate totalmarkings and attendance

            ' for each classmarking with matching classid:
            ' for each studentmarkentry with matching studentid:
            ' add 1 onto totalMarkings
            ' add 1 onto attendance if .markdata(0) is true

            For classMarking = 0 To maxClassMarking
                With classMarkings(classMarking)
                    If .classId = students(selectedStudent).classId Then
                        For markEntry = 0 To .maxStudentMarkEntry
                            If .studentMarkEntries(markEntry).studentId = students(selectedStudent).id Then
                                'totalMarkings += 1
                                tempStr += vbCr & .entryDate & ","
                                If CBool(.studentMarkEntries(markEntry).markData(0).data) Then
                                    tempStr += "Present"
                                    'attendance += 1
                                Else
                                    tempStr += "Absent"
                                End If
                                markEntry = .maxStudentMarkEntry + 1 ' exit loop
                            End If
                        Next
                    End If
                End With
            Next
            ' export the csv file
            FileNum = FreeFile()
            FileOpen(fileNum, sfdSaveFile.FileName, OpenMode.Output)
            Write(FileNum, tempStr)
            FileClose(fileNum)
        End If
    End Sub
End Class