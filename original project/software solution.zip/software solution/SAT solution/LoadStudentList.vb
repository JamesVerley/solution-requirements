﻿' last edited 17/08/17
' by James Verley 2017 term 3
' a powerful tool which allows the user to enter raw text from a file or textbox input and convert to student records

Public Class LoadStudentList
    Public tempStudents(999) As Student ' array of length 1000 for holding formatted records
    Public defaultStudent As Student
    Public maxTempStudent As Integer
    ' studentProperties(), an array for storing names of student property descriptors
    Public studentProperties() As String = {"first name", "last name", "age/birthdate", "gender", "comment", "skip property"}
    Public maxStudentProperty As Integer = studentProperties.Length - 1
    Public maxSelectedStudentProperty As Integer = -1
    ' selectedStudentPropertyIndices, for storing descriptors which have been appended to the property list
    Public selectedStudentPropertyIndices(20) As Integer
    Public studentPropertyIndices(20) As Integer

    Private Sub LoadStudentList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' tooltips
        AddToolTip(txtPropertySeperator, "enter the character(s) which separate each student property. e.g: Fname,Sname,Age,Gender = ','")
        AddToolTip(txtRecordSeperator, "enter the character(s) which separate each student record. e.g: " & vbCr & "Fname,Sname,Age,Gender" & vbCr & "Fname2,Sname2,Age2,Gender2 = (you would tick 'newline')")

        ' student properties appended to listbox
        maxTempStudent = -1
        For i = 0 To maxStudentProperty
            lstStudentProperties.Items.Add(studentProperties(i))
            studentPropertyIndices(i) = i
        Next

        ' create a default student record which has details to fill out those missing on formatted ones
        With defaultStudent
            .birthdate = Date.Now.AddYears(-13)
            .comment = ""
            .fname = "New"
            .lname = "student"
            .gender = 0
        End With
    End Sub

    Private Sub btnAppendProperty_Click(sender As Object, e As EventArgs) Handles btnAppendProperty.Click
        item = lstStudentProperties.SelectedIndex
        If item <> -1 And maxSelectedStudentProperty < 20 Then
            maxSelectedStudentProperty += 1
            ' index at the total number of student properties - 1, minus the maxStudentProperty (at the start this will always be 0)
            selectedStudentPropertyIndices(maxSelectedStudentProperty) = studentPropertyIndices(item) ' add item of listbox indices to selected property list

            ' exchange property from one list to the other unless property is "skip"
            If studentProperties(studentPropertyIndices(item)) <> "skip Property" Then
                ' set selected item to last property, then forget the last property
                studentPropertyIndices(item) = studentPropertyIndices(maxStudentProperty)
                maxStudentProperty -= 1
            End If
            UpdateProperties() ' apply changes to interface
        End If
    End Sub

    Private Sub btnRemoveProperty_Click(sender As Object, e As EventArgs) Handles btnRemoveProperty.Click
        item = lstSelectedStudentProperties.SelectedIndex

        If item <> -1 Then ' if something is selected

            If studentProperties(selectedStudentPropertyIndices(item)) <> "skip Property" Then ' if skip isn't being removed
                maxStudentProperty += 1
                studentPropertyIndices(maxStudentProperty) = selectedStudentPropertyIndices(item)
            End If
            ' set selected item to last property, then forget the last property
            selectedStudentPropertyIndices(item) = selectedStudentPropertyIndices(maxSelectedStudentProperty)
            maxSelectedStudentProperty -= 1
            UpdateProperties() ' apply changes to interface
        End If
    End Sub

    ' called when a user moves a student property from one listbox to another to update interface
    Private Sub UpdateProperties()
        lstStudentProperties.Items.Clear()
        lstSelectedStudentProperties.Items.Clear()
        For i = 0 To maxStudentProperty
            lstStudentProperties.Items.Add(studentProperties(studentPropertyIndices(i)))
        Next
        For i = 0 To maxSelectedStudentProperty
            lstSelectedStudentProperties.Items.Add(studentProperties(selectedStudentPropertyIndices(i)))
        Next
    End Sub

    Private Sub chkPropertySeperatorIsNewline_CheckedChanged(sender As Object, e As EventArgs) Handles chkPropertySeperatorIsNewline.CheckedChanged
        ' uncheck other checkbox if this one is being checked
        If chkRecordSeperatorIsNewline.Checked Then
            chkRecordSeperatorIsNewline.Checked = Not chkPropertySeperatorIsNewline.Checked
        End If
        ' set enabled state of adjacent textbox to oppostite of checked state
        txtPropertySeperator.Enabled = Not chkPropertySeperatorIsNewline.Checked
    End Sub

    Private Sub chkRecordSeperatorIsNewline_CheckedChanged(sender As Object, e As EventArgs) Handles chkRecordSeperatorIsNewline.CheckedChanged
        ' uncheck other checkbox if this one is being checked
        If chkPropertySeperatorIsNewline.Checked Then
            chkPropertySeperatorIsNewline.Checked = Not chkRecordSeperatorIsNewline.Checked
        End If
        ' set enabled state of adjacent textbox to oppostite of checked state
        txtRecordSeperator.Enabled = Not chkRecordSeperatorIsNewline.Checked
    End Sub

    Private Sub btnLoadFile_Click(sender As Object, e As EventArgs) Handles btnLoadFile.Click
        'the filename (will show in the filename box)
        ofdLoadFile.FileName = ""
        'the title of the window to open a file
        ofdLoadFile.Title = "Open File..."
        'the filetypes to allow the user to view
        ofdLoadFile.Filter = "PLAIN TEXT FILES|*.txt;*.csv;"
        'now to open the dialog and check if OK has been pressed
        If ofdLoadFile.ShowDialog = DialogResult.OK Then
            txtLoadedData.Text = ""
            Dim fileNum As Integer = FreeFile()
            FileOpen(fileNum, ofdLoadFile.FileName, OpenMode.Input)
            Do Until EOF(fileNum)
                txtLoadedData.Text += LineInput(fileNum) & vbCrLf
            Loop
            FileClose(fileNum)
        End If
    End Sub

    Private Sub btnFormatRecords_Click(sender As Object, e As EventArgs) Handles btnFormatRecords.Click
        ' make sure the user has actually put something in the student data textbox
        If txtLoadedData.Text.Length < 1 Then
            MessageBox.Show("Please input Or load some student data")
            Return
        End If

        Dim tempRecordStr() As String ' a list of strings, each containing a string of student details
        Dim tempPropertiesStr(20) As String ' a list of strings, each containing a string of individual student properties
        Dim maxTempProperties As Integer ' an integer value containing the maximum valid index of tempProperties
        If chkRecordSeperatorIsNewline.Checked Then
            tempRecordStr = txtLoadedData.Text.Split(vbCr) ' split records by newline
        Else
            tempRecordStr = txtLoadedData.Text.Split(txtRecordSeperator.Text) ' split records by string entered into textbox
        End If

        ' loop through loaded records by separator
        For i = 0 To tempRecordStr.Length - 1

            ' Split records by newline if checkbox is checked, else split by character
            If chkPropertySeperatorIsNewline.Checked Then
                tempPropertiesStr = tempRecordStr(i).Split(vbCrLf)
            Else
                tempPropertiesStr = tempRecordStr(i).Split(txtPropertySeperator.Text)
                maxTempProperties = tempRecordStr(i).Split(txtPropertySeperator.Text).Length
            End If
            If tempPropertiesStr.Length - 1 = maxSelectedStudentProperty Then ' if length of split properties string equals number of criteria selected
                tempStudents(i) = defaultStudent
                Try
                    ' now loop through all properties of that record and 
                    For ii = 0 To maxSelectedStudentProperty
                        tempPropertiesStr(ii) = tempPropertiesStr(ii).Split(vbCr)(0)
                        Select Case selectedStudentPropertyIndices(ii)
                            Case 0 ' first name
                                tempStudents(i).fname = tempPropertiesStr(ii)
                            Case 1 ' last name
                                tempStudents(i).lname = tempPropertiesStr(ii)
                            Case 2 ' age
                                If tempPropertiesStr(ii).Length > 3 Then
                                    tempStudents(i).birthdate = CDate(tempPropertiesStr(ii))
                                Else
                                    tempStudents(i).birthdate = Date.Now.AddYears(-CInt(tempPropertiesStr(ii)))
                                End If

                            Case 3 ' gender
                                tempLine = tempPropertiesStr(ii).ToLower()
                                If tempLine = "female" Or tempLine = "f" Or tempLine = "girl" Or tempLine = "g" Then
                                    tempStudents(i).gender = 1
                                Else
                                    tempStudents(i).gender = 0
                                End If
                            Case 4 ' comment
                                tempStudents(i).comment = tempPropertiesStr(ii)
                        End Select
                    Next
                Catch
                    ' show an error message based on incorrect data types
                    MessageBox.Show("There was an Error In the input data, most likely caused by an incorrect order Of student properties")
                    Return
                End Try
            Else
                'show an error message based on incorrectly processed record lengths
                MessageBox.Show("could Not format records, please make sure you've entered the correct record and property seperators, the correct order and number of student properties, and loaded some valid data")
                Return
            End If
        Next
        maxTempStudent = tempRecordStr.Length - 1 ' update the maximum student record being held on this form
        lstLoadedStudents.Items.Clear() ' clear the students listbox
        For item = 0 To maxTempStudent
            lstLoadedStudents.Items.Add(tempStudents(item).fname & " " & tempStudents(item).lname) 'fill the listbox with loaded student names
        Next
    End Sub

    ' append all temporary records to the students list after assigning them a class
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        ' make sure the user has selected a class for the student records being loaded
        If cboClass.SelectedIndex = -1 Then
            MessageBox.Show("Please select a class")
            Return
        End If

        Dim maxId As Integer = students(maxStudent).id
        For item = 0 To maxTempStudent
            'apply id data to temporary record
            tempStudents(item).classId = classRecords(cboClass.SelectedIndex).id
            tempStudents(item).id = maxId + item + 1

            ' add students to the next maximum index of existing student list + the index of the student being added
            students(maxStudent + item + 1) = tempStudents(item)
        Next
        maxStudent = maxId + maxTempStudent + 1 ' update the maximum index in the newly modified students list which contains a non-empty record
        Main.UpdateStudents()
        Close()
    End Sub
End Class