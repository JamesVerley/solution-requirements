﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabClassMarking = New System.Windows.Forms.TabPage()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.lblPeriod_ClassMarking = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.lblDate_ClassMarking = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.lblClass_ClassMarking = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblProfile_ClassMarking = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.lblStudentsMarked_CLassMarking = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblAttendance_ClassMarking = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnMarkClass_ClassMarking = New System.Windows.Forms.Button()
        Me.btnEdit_ClassMarking = New System.Windows.Forms.Button()
        Me.btnDelete_ClassMarking = New System.Windows.Forms.Button()
        Me.cboPeriodSearch_ClassMarking = New System.Windows.Forms.ComboBox()
        Me.lstClassEntries_ClassMarking = New System.Windows.Forms.ListBox()
        Me.cboClassSearch_ClassMarking = New System.Windows.Forms.ComboBox()
        Me.cboTermSearch_ClassMarking = New System.Windows.Forms.ComboBox()
        Me.cboYearSearch_ClassMarking = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.tabStudents = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblClassFilter = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtComment_Students = New System.Windows.Forms.TextBox()
        Me.btnLoadList_Students = New System.Windows.Forms.Button()
        Me.imgIcon_Students = New System.Windows.Forms.PictureBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblGender_Students = New System.Windows.Forms.Label()
        Me.lstStudents_Students = New System.Windows.Forms.ListBox()
        Me.lstStudentClasses_Students = New System.Windows.Forms.ListBox()
        Me.btnDeleteStudent_Students = New System.Windows.Forms.Button()
        Me.btnNew_Students = New System.Windows.Forms.Button()
        Me.lblAge_Students = New System.Windows.Forms.Label()
        Me.btnEdit_Students = New System.Windows.Forms.Button()
        Me.lblName_Students = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnDeselect_Students = New System.Windows.Forms.Button()
        Me.nudClassId_Students = New System.Windows.Forms.NumericUpDown()
        Me.label21 = New System.Windows.Forms.Label()
        Me.btnNewClass_Students = New System.Windows.Forms.Button()
        Me.txtClassYear_Students = New System.Windows.Forms.TextBox()
        Me.txtClassName_Students = New System.Windows.Forms.TextBox()
        Me.lstClasses_Students = New System.Windows.Forms.ListBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnDeleteClass_Students = New System.Windows.Forms.Button()
        Me.btnSaveClass_Students = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.tabLessonProfiles = New System.Windows.Forms.TabPage()
        Me.lstCriteria_Criteria = New System.Windows.Forms.ListBox()
        Me.btnResetCriteria_Criteria = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.nudMax_Criteria = New System.Windows.Forms.NumericUpDown()
        Me.txtDefault_Criteria = New System.Windows.Forms.TextBox()
        Me.nudDefault_Criteria = New System.Windows.Forms.NumericUpDown()
        Me.chkDefault_Criteria = New System.Windows.Forms.CheckBox()
        Me.cboDefault_Criteria = New System.Windows.Forms.ComboBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.nudId_Criteria = New System.Windows.Forms.NumericUpDown()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.cboDataType_Criteria = New System.Windows.Forms.ComboBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtCriteriaName_Criteria = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnDeleteCriteria_Criteria = New System.Windows.Forms.Button()
        Me.btnSave_Criteria = New System.Windows.Forms.Button()
        Me.btnAddCriteria_Criteria = New System.Windows.Forms.Button()
        Me.txtProfileName_Criteria = New System.Windows.Forms.TextBox()
        Me.btnNewProfile_Criteria = New System.Windows.Forms.Button()
        Me.btnDeleteProfile_Criteria = New System.Windows.Forms.Button()
        Me.lstProfiles_Criteria = New System.Windows.Forms.ListBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.tabReport = New System.Windows.Forms.TabPage()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.btnExportSpreadsheet_GenerateReport = New System.Windows.Forms.Button()
        Me.cboTerm_GenerateReport = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.lstStudents_GenerateReport = New System.Windows.Forms.ListBox()
        Me.btnGenerateReport = New System.Windows.Forms.Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.cboClass_GenerateReport = New System.Windows.Forms.ComboBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.lblTotalSessions_GenerateReport = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.lblTotalAttended_GenerateReport = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.lblAttendance_GenerateReport = New System.Windows.Forms.Label()
        Me.lblProgressTitle_GenerateReport = New System.Windows.Forms.Label()
        Me.label123 = New System.Windows.Forms.Label()
        Me.sfdSaveFile = New System.Windows.Forms.SaveFileDialog()
        Me.TabControl1.SuspendLayout()
        Me.tabClassMarking.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.tabStudents.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.imgIcon_Students, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.nudClassId_Students, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabLessonProfiles.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.nudMax_Criteria, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudDefault_Criteria, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudId_Criteria, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabReport.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabClassMarking)
        Me.TabControl1.Controls.Add(Me.tabStudents)
        Me.TabControl1.Controls.Add(Me.tabLessonProfiles)
        Me.TabControl1.Controls.Add(Me.tabReport)
        Me.TabControl1.Location = New System.Drawing.Point(10, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(922, 627)
        Me.TabControl1.TabIndex = 0
        '
        'tabClassMarking
        '
        Me.tabClassMarking.Controls.Add(Me.GroupBox5)
        Me.tabClassMarking.Controls.Add(Me.GroupBox4)
        Me.tabClassMarking.Controls.Add(Me.btnMarkClass_ClassMarking)
        Me.tabClassMarking.Controls.Add(Me.btnEdit_ClassMarking)
        Me.tabClassMarking.Controls.Add(Me.btnDelete_ClassMarking)
        Me.tabClassMarking.Controls.Add(Me.cboPeriodSearch_ClassMarking)
        Me.tabClassMarking.Controls.Add(Me.lstClassEntries_ClassMarking)
        Me.tabClassMarking.Controls.Add(Me.cboClassSearch_ClassMarking)
        Me.tabClassMarking.Controls.Add(Me.cboTermSearch_ClassMarking)
        Me.tabClassMarking.Controls.Add(Me.cboYearSearch_ClassMarking)
        Me.tabClassMarking.Controls.Add(Me.Label9)
        Me.tabClassMarking.Controls.Add(Me.Label8)
        Me.tabClassMarking.Controls.Add(Me.Label7)
        Me.tabClassMarking.Controls.Add(Me.Label6)
        Me.tabClassMarking.Location = New System.Drawing.Point(4, 22)
        Me.tabClassMarking.Name = "tabClassMarking"
        Me.tabClassMarking.Padding = New System.Windows.Forms.Padding(3)
        Me.tabClassMarking.Size = New System.Drawing.Size(914, 601)
        Me.tabClassMarking.TabIndex = 0
        Me.tabClassMarking.Text = "Mark Class"
        Me.tabClassMarking.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.lblPeriod_ClassMarking)
        Me.GroupBox5.Controls.Add(Me.Label29)
        Me.GroupBox5.Controls.Add(Me.lblDate_ClassMarking)
        Me.GroupBox5.Controls.Add(Me.Label26)
        Me.GroupBox5.Controls.Add(Me.lblClass_ClassMarking)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.lblProfile_ClassMarking)
        Me.GroupBox5.Controls.Add(Me.Label25)
        Me.GroupBox5.Location = New System.Drawing.Point(499, 50)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(260, 172)
        Me.GroupBox5.TabIndex = 38
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Info"
        '
        'lblPeriod_ClassMarking
        '
        Me.lblPeriod_ClassMarking.AutoSize = True
        Me.lblPeriod_ClassMarking.Location = New System.Drawing.Point(84, 58)
        Me.lblPeriod_ClassMarking.Name = "lblPeriod_ClassMarking"
        Me.lblPeriod_ClassMarking.Size = New System.Drawing.Size(13, 13)
        Me.lblPeriod_ClassMarking.TabIndex = 41
        Me.lblPeriod_ClassMarking.Text = "--"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(6, 58)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(40, 13)
        Me.Label29.TabIndex = 40
        Me.Label29.Text = "Period:"
        '
        'lblDate_ClassMarking
        '
        Me.lblDate_ClassMarking.AutoSize = True
        Me.lblDate_ClassMarking.Location = New System.Drawing.Point(84, 29)
        Me.lblDate_ClassMarking.Name = "lblDate_ClassMarking"
        Me.lblDate_ClassMarking.Size = New System.Drawing.Size(13, 13)
        Me.lblDate_ClassMarking.TabIndex = 39
        Me.lblDate_ClassMarking.Text = "--"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(6, 29)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(33, 13)
        Me.Label26.TabIndex = 38
        Me.Label26.Text = "Date:"
        '
        'lblClass_ClassMarking
        '
        Me.lblClass_ClassMarking.AutoSize = True
        Me.lblClass_ClassMarking.Location = New System.Drawing.Point(84, 84)
        Me.lblClass_ClassMarking.Name = "lblClass_ClassMarking"
        Me.lblClass_ClassMarking.Size = New System.Drawing.Size(13, 13)
        Me.lblClass_ClassMarking.TabIndex = 37
        Me.lblClass_ClassMarking.Text = "--"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 84)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 36
        Me.Label4.Text = "Class:"
        '
        'lblProfile_ClassMarking
        '
        Me.lblProfile_ClassMarking.AutoSize = True
        Me.lblProfile_ClassMarking.Location = New System.Drawing.Point(84, 112)
        Me.lblProfile_ClassMarking.Name = "lblProfile_ClassMarking"
        Me.lblProfile_ClassMarking.Size = New System.Drawing.Size(13, 13)
        Me.lblProfile_ClassMarking.TabIndex = 35
        Me.lblProfile_ClassMarking.Text = "--"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(6, 112)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(39, 13)
        Me.Label25.TabIndex = 34
        Me.Label25.Text = "Profile:"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.lblStudentsMarked_CLassMarking)
        Me.GroupBox4.Controls.Add(Me.Label3)
        Me.GroupBox4.Controls.Add(Me.lblAttendance_ClassMarking)
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Location = New System.Drawing.Point(499, 228)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(260, 216)
        Me.GroupBox4.TabIndex = 35
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Statistics"
        '
        'lblStudentsMarked_CLassMarking
        '
        Me.lblStudentsMarked_CLassMarking.AutoSize = True
        Me.lblStudentsMarked_CLassMarking.Location = New System.Drawing.Point(103, 16)
        Me.lblStudentsMarked_CLassMarking.Name = "lblStudentsMarked_CLassMarking"
        Me.lblStudentsMarked_CLassMarking.Size = New System.Drawing.Size(13, 13)
        Me.lblStudentsMarked_CLassMarking.TabIndex = 37
        Me.lblStudentsMarked_CLassMarking.Text = "--"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(91, 13)
        Me.Label3.TabIndex = 36
        Me.Label3.Text = "Students Marked:"
        '
        'lblAttendance_ClassMarking
        '
        Me.lblAttendance_ClassMarking.AutoSize = True
        Me.lblAttendance_ClassMarking.Location = New System.Drawing.Point(103, 34)
        Me.lblAttendance_ClassMarking.Name = "lblAttendance_ClassMarking"
        Me.lblAttendance_ClassMarking.Size = New System.Drawing.Size(13, 13)
        Me.lblAttendance_ClassMarking.TabIndex = 35
        Me.lblAttendance_ClassMarking.Text = "--"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 13)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "Attendance rate:"
        '
        'btnMarkClass_ClassMarking
        '
        Me.btnMarkClass_ClassMarking.Location = New System.Drawing.Point(6, 50)
        Me.btnMarkClass_ClassMarking.Name = "btnMarkClass_ClassMarking"
        Me.btnMarkClass_ClassMarking.Size = New System.Drawing.Size(92, 54)
        Me.btnMarkClass_ClassMarking.TabIndex = 33
        Me.btnMarkClass_ClassMarking.Text = "Mark A Class"
        Me.btnMarkClass_ClassMarking.UseVisualStyleBackColor = True
        '
        'btnEdit_ClassMarking
        '
        Me.btnEdit_ClassMarking.Location = New System.Drawing.Point(104, 448)
        Me.btnEdit_ClassMarking.Name = "btnEdit_ClassMarking"
        Me.btnEdit_ClassMarking.Size = New System.Drawing.Size(124, 23)
        Me.btnEdit_ClassMarking.TabIndex = 31
        Me.btnEdit_ClassMarking.Text = "Edit marking record"
        Me.btnEdit_ClassMarking.UseVisualStyleBackColor = True
        '
        'btnDelete_ClassMarking
        '
        Me.btnDelete_ClassMarking.Location = New System.Drawing.Point(234, 448)
        Me.btnDelete_ClassMarking.Name = "btnDelete_ClassMarking"
        Me.btnDelete_ClassMarking.Size = New System.Drawing.Size(124, 23)
        Me.btnDelete_ClassMarking.TabIndex = 30
        Me.btnDelete_ClassMarking.Text = "Delete marking record"
        Me.btnDelete_ClassMarking.UseVisualStyleBackColor = True
        '
        'cboPeriodSearch_ClassMarking
        '
        Me.cboPeriodSearch_ClassMarking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPeriodSearch_ClassMarking.FormattingEnabled = True
        Me.cboPeriodSearch_ClassMarking.Location = New System.Drawing.Point(270, 23)
        Me.cboPeriodSearch_ClassMarking.Name = "cboPeriodSearch_ClassMarking"
        Me.cboPeriodSearch_ClassMarking.Size = New System.Drawing.Size(77, 21)
        Me.cboPeriodSearch_ClassMarking.TabIndex = 29
        '
        'lstClassEntries_ClassMarking
        '
        Me.lstClassEntries_ClassMarking.FormattingEnabled = True
        Me.lstClassEntries_ClassMarking.Location = New System.Drawing.Point(104, 50)
        Me.lstClassEntries_ClassMarking.Name = "lstClassEntries_ClassMarking"
        Me.lstClassEntries_ClassMarking.Size = New System.Drawing.Size(389, 394)
        Me.lstClassEntries_ClassMarking.TabIndex = 28
        '
        'cboClassSearch_ClassMarking
        '
        Me.cboClassSearch_ClassMarking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboClassSearch_ClassMarking.FormattingEnabled = True
        Me.cboClassSearch_ClassMarking.Location = New System.Drawing.Point(353, 22)
        Me.cboClassSearch_ClassMarking.Name = "cboClassSearch_ClassMarking"
        Me.cboClassSearch_ClassMarking.Size = New System.Drawing.Size(121, 21)
        Me.cboClassSearch_ClassMarking.TabIndex = 25
        '
        'cboTermSearch_ClassMarking
        '
        Me.cboTermSearch_ClassMarking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTermSearch_ClassMarking.FormattingEnabled = True
        Me.cboTermSearch_ClassMarking.Location = New System.Drawing.Point(187, 23)
        Me.cboTermSearch_ClassMarking.Name = "cboTermSearch_ClassMarking"
        Me.cboTermSearch_ClassMarking.Size = New System.Drawing.Size(77, 21)
        Me.cboTermSearch_ClassMarking.TabIndex = 24
        '
        'cboYearSearch_ClassMarking
        '
        Me.cboYearSearch_ClassMarking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboYearSearch_ClassMarking.FormattingEnabled = True
        Me.cboYearSearch_ClassMarking.Location = New System.Drawing.Point(104, 23)
        Me.cboYearSearch_ClassMarking.Name = "cboYearSearch_ClassMarking"
        Me.cboYearSearch_ClassMarking.Size = New System.Drawing.Size(77, 21)
        Me.cboYearSearch_ClassMarking.TabIndex = 22
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(350, 2)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(32, 13)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Class"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(267, 2)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(37, 13)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "Period"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(184, 2)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(31, 13)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "Term"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(101, 2)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 13)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Year"
        '
        'tabStudents
        '
        Me.tabStudents.BackColor = System.Drawing.Color.White
        Me.tabStudents.Controls.Add(Me.GroupBox2)
        Me.tabStudents.Controls.Add(Me.GroupBox1)
        Me.tabStudents.Location = New System.Drawing.Point(4, 22)
        Me.tabStudents.Name = "tabStudents"
        Me.tabStudents.Padding = New System.Windows.Forms.Padding(3)
        Me.tabStudents.Size = New System.Drawing.Size(914, 601)
        Me.tabStudents.TabIndex = 1
        Me.tabStudents.Text = "Students"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblClassFilter)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.txtComment_Students)
        Me.GroupBox2.Controls.Add(Me.btnLoadList_Students)
        Me.GroupBox2.Controls.Add(Me.imgIcon_Students)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.lblGender_Students)
        Me.GroupBox2.Controls.Add(Me.lstStudents_Students)
        Me.GroupBox2.Controls.Add(Me.lstStudentClasses_Students)
        Me.GroupBox2.Controls.Add(Me.btnDeleteStudent_Students)
        Me.GroupBox2.Controls.Add(Me.btnNew_Students)
        Me.GroupBox2.Controls.Add(Me.lblAge_Students)
        Me.GroupBox2.Controls.Add(Me.btnEdit_Students)
        Me.GroupBox2.Controls.Add(Me.lblName_Students)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 222)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(778, 359)
        Me.GroupBox2.TabIndex = 22
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Student details"
        '
        'lblClassFilter
        '
        Me.lblClassFilter.AutoSize = True
        Me.lblClassFilter.Location = New System.Drawing.Point(138, 33)
        Me.lblClassFilter.Name = "lblClassFilter"
        Me.lblClassFilter.Size = New System.Drawing.Size(83, 13)
        Me.lblClassFilter.TabIndex = 22
        Me.lblClassFilter.Text = "From All Classes"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(576, 83)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(86, 13)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Classes enrolled:"
        '
        'txtComment_Students
        '
        Me.txtComment_Students.Location = New System.Drawing.Point(259, 174)
        Me.txtComment_Students.Multiline = True
        Me.txtComment_Students.Name = "txtComment_Students"
        Me.txtComment_Students.ReadOnly = True
        Me.txtComment_Students.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtComment_Students.Size = New System.Drawing.Size(491, 118)
        Me.txtComment_Students.TabIndex = 16
        '
        'btnLoadList_Students
        '
        Me.btnLoadList_Students.Location = New System.Drawing.Point(162, 319)
        Me.btnLoadList_Students.Name = "btnLoadList_Students"
        Me.btnLoadList_Students.Size = New System.Drawing.Size(59, 23)
        Me.btnLoadList_Students.TabIndex = 6
        Me.btnLoadList_Students.Text = "load list"
        Me.btnLoadList_Students.UseVisualStyleBackColor = True
        '
        'imgIcon_Students
        '
        Me.imgIcon_Students.Location = New System.Drawing.Point(259, 49)
        Me.imgIcon_Students.Name = "imgIcon_Students"
        Me.imgIcon_Students.Size = New System.Drawing.Size(152, 119)
        Me.imgIcon_Students.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.imgIcon_Students.TabIndex = 15
        Me.imgIcon_Students.TabStop = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(13, 33)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(49, 13)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Students"
        '
        'lblGender_Students
        '
        Me.lblGender_Students.AutoSize = True
        Me.lblGender_Students.Location = New System.Drawing.Point(417, 107)
        Me.lblGender_Students.Name = "lblGender_Students"
        Me.lblGender_Students.Size = New System.Drawing.Size(42, 13)
        Me.lblGender_Students.TabIndex = 20
        Me.lblGender_Students.Text = "Gender"
        '
        'lstStudents_Students
        '
        Me.lstStudents_Students.FormattingEnabled = True
        Me.lstStudents_Students.Location = New System.Drawing.Point(16, 49)
        Me.lstStudents_Students.Name = "lstStudents_Students"
        Me.lstStudents_Students.Size = New System.Drawing.Size(205, 264)
        Me.lstStudents_Students.TabIndex = 2
        '
        'lstStudentClasses_Students
        '
        Me.lstStudentClasses_Students.FormattingEnabled = True
        Me.lstStudentClasses_Students.Location = New System.Drawing.Point(579, 99)
        Me.lstStudentClasses_Students.Name = "lstStudentClasses_Students"
        Me.lstStudentClasses_Students.Size = New System.Drawing.Size(171, 69)
        Me.lstStudentClasses_Students.TabIndex = 17
        '
        'btnDeleteStudent_Students
        '
        Me.btnDeleteStudent_Students.Location = New System.Drawing.Point(16, 319)
        Me.btnDeleteStudent_Students.Name = "btnDeleteStudent_Students"
        Me.btnDeleteStudent_Students.Size = New System.Drawing.Size(46, 23)
        Me.btnDeleteStudent_Students.TabIndex = 3
        Me.btnDeleteStudent_Students.Text = "Delete"
        Me.btnDeleteStudent_Students.UseVisualStyleBackColor = True
        '
        'btnNew_Students
        '
        Me.btnNew_Students.Location = New System.Drawing.Point(68, 319)
        Me.btnNew_Students.Name = "btnNew_Students"
        Me.btnNew_Students.Size = New System.Drawing.Size(41, 23)
        Me.btnNew_Students.TabIndex = 4
        Me.btnNew_Students.Text = "New"
        Me.btnNew_Students.UseVisualStyleBackColor = True
        '
        'lblAge_Students
        '
        Me.lblAge_Students.AutoSize = True
        Me.lblAge_Students.Location = New System.Drawing.Point(417, 136)
        Me.lblAge_Students.Name = "lblAge_Students"
        Me.lblAge_Students.Size = New System.Drawing.Size(26, 13)
        Me.lblAge_Students.TabIndex = 19
        Me.lblAge_Students.Text = "Age"
        '
        'btnEdit_Students
        '
        Me.btnEdit_Students.Location = New System.Drawing.Point(115, 319)
        Me.btnEdit_Students.Name = "btnEdit_Students"
        Me.btnEdit_Students.Size = New System.Drawing.Size(41, 23)
        Me.btnEdit_Students.TabIndex = 5
        Me.btnEdit_Students.Text = "Edit"
        Me.btnEdit_Students.UseVisualStyleBackColor = True
        '
        'lblName_Students
        '
        Me.lblName_Students.AutoSize = True
        Me.lblName_Students.Location = New System.Drawing.Point(417, 76)
        Me.lblName_Students.Name = "lblName_Students"
        Me.lblName_Students.Size = New System.Drawing.Size(35, 13)
        Me.lblName_Students.TabIndex = 18
        Me.lblName_Students.Text = "Name"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnDeselect_Students)
        Me.GroupBox1.Controls.Add(Me.nudClassId_Students)
        Me.GroupBox1.Controls.Add(Me.label21)
        Me.GroupBox1.Controls.Add(Me.btnNewClass_Students)
        Me.GroupBox1.Controls.Add(Me.txtClassYear_Students)
        Me.GroupBox1.Controls.Add(Me.txtClassName_Students)
        Me.GroupBox1.Controls.Add(Me.lstClasses_Students)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.btnDeleteClass_Students)
        Me.GroupBox1.Controls.Add(Me.btnSaveClass_Students)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(778, 210)
        Me.GroupBox1.TabIndex = 21
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Edit class details"
        '
        'btnDeselect_Students
        '
        Me.btnDeselect_Students.Location = New System.Drawing.Point(114, 178)
        Me.btnDeselect_Students.Name = "btnDeselect_Students"
        Me.btnDeselect_Students.Size = New System.Drawing.Size(62, 23)
        Me.btnDeselect_Students.TabIndex = 19
        Me.btnDeselect_Students.Text = "Deselect"
        Me.btnDeselect_Students.UseVisualStyleBackColor = True
        '
        'nudClassId_Students
        '
        Me.nudClassId_Students.Location = New System.Drawing.Point(332, 139)
        Me.nudClassId_Students.Name = "nudClassId_Students"
        Me.nudClassId_Students.Size = New System.Drawing.Size(137, 20)
        Me.nudClassId_Students.TabIndex = 18
        '
        'label21
        '
        Me.label21.AutoSize = True
        Me.label21.Location = New System.Drawing.Point(291, 141)
        Me.label21.Name = "label21"
        Me.label21.Size = New System.Drawing.Size(16, 13)
        Me.label21.TabIndex = 17
        Me.label21.Text = "Id"
        '
        'btnNewClass_Students
        '
        Me.btnNewClass_Students.Location = New System.Drawing.Point(62, 178)
        Me.btnNewClass_Students.Name = "btnNewClass_Students"
        Me.btnNewClass_Students.Size = New System.Drawing.Size(46, 23)
        Me.btnNewClass_Students.TabIndex = 15
        Me.btnNewClass_Students.Text = "New"
        Me.btnNewClass_Students.UseVisualStyleBackColor = True
        '
        'txtClassYear_Students
        '
        Me.txtClassYear_Students.Location = New System.Drawing.Point(332, 113)
        Me.txtClassYear_Students.MaxLength = 4
        Me.txtClassYear_Students.Name = "txtClassYear_Students"
        Me.txtClassYear_Students.Size = New System.Drawing.Size(137, 20)
        Me.txtClassYear_Students.TabIndex = 11
        '
        'txtClassName_Students
        '
        Me.txtClassName_Students.Location = New System.Drawing.Point(332, 87)
        Me.txtClassName_Students.MaxLength = 30
        Me.txtClassName_Students.Name = "txtClassName_Students"
        Me.txtClassName_Students.Size = New System.Drawing.Size(137, 20)
        Me.txtClassName_Students.TabIndex = 10
        '
        'lstClasses_Students
        '
        Me.lstClasses_Students.FormattingEnabled = True
        Me.lstClasses_Students.Location = New System.Drawing.Point(10, 38)
        Me.lstClasses_Students.Name = "lstClasses_Students"
        Me.lstClasses_Students.Size = New System.Drawing.Size(211, 134)
        Me.lstClasses_Students.TabIndex = 7
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(7, 22)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(43, 13)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "Classes"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(291, 90)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(35, 13)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "Name"
        '
        'btnDeleteClass_Students
        '
        Me.btnDeleteClass_Students.Location = New System.Drawing.Point(10, 178)
        Me.btnDeleteClass_Students.Name = "btnDeleteClass_Students"
        Me.btnDeleteClass_Students.Size = New System.Drawing.Size(46, 23)
        Me.btnDeleteClass_Students.TabIndex = 9
        Me.btnDeleteClass_Students.Text = "Delete"
        Me.btnDeleteClass_Students.UseVisualStyleBackColor = True
        '
        'btnSaveClass_Students
        '
        Me.btnSaveClass_Students.Location = New System.Drawing.Point(488, 99)
        Me.btnSaveClass_Students.Name = "btnSaveClass_Students"
        Me.btnSaveClass_Students.Size = New System.Drawing.Size(59, 46)
        Me.btnSaveClass_Students.TabIndex = 14
        Me.btnSaveClass_Students.Text = "Save"
        Me.btnSaveClass_Students.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(291, 116)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(29, 13)
        Me.Label13.TabIndex = 13
        Me.Label13.Text = "Year"
        '
        'tabLessonProfiles
        '
        Me.tabLessonProfiles.Controls.Add(Me.lstCriteria_Criteria)
        Me.tabLessonProfiles.Controls.Add(Me.btnResetCriteria_Criteria)
        Me.tabLessonProfiles.Controls.Add(Me.GroupBox3)
        Me.tabLessonProfiles.Controls.Add(Me.btnDeleteCriteria_Criteria)
        Me.tabLessonProfiles.Controls.Add(Me.btnSave_Criteria)
        Me.tabLessonProfiles.Controls.Add(Me.btnAddCriteria_Criteria)
        Me.tabLessonProfiles.Controls.Add(Me.txtProfileName_Criteria)
        Me.tabLessonProfiles.Controls.Add(Me.btnNewProfile_Criteria)
        Me.tabLessonProfiles.Controls.Add(Me.btnDeleteProfile_Criteria)
        Me.tabLessonProfiles.Controls.Add(Me.lstProfiles_Criteria)
        Me.tabLessonProfiles.Controls.Add(Me.Label17)
        Me.tabLessonProfiles.Location = New System.Drawing.Point(4, 22)
        Me.tabLessonProfiles.Name = "tabLessonProfiles"
        Me.tabLessonProfiles.Size = New System.Drawing.Size(914, 601)
        Me.tabLessonProfiles.TabIndex = 2
        Me.tabLessonProfiles.Text = "Profiles"
        Me.tabLessonProfiles.UseVisualStyleBackColor = True
        '
        'lstCriteria_Criteria
        '
        Me.lstCriteria_Criteria.FormattingEnabled = True
        Me.lstCriteria_Criteria.Location = New System.Drawing.Point(7, 248)
        Me.lstCriteria_Criteria.Name = "lstCriteria_Criteria"
        Me.lstCriteria_Criteria.Size = New System.Drawing.Size(232, 147)
        Me.lstCriteria_Criteria.TabIndex = 0
        '
        'btnResetCriteria_Criteria
        '
        Me.btnResetCriteria_Criteria.Location = New System.Drawing.Point(393, 401)
        Me.btnResetCriteria_Criteria.Name = "btnResetCriteria_Criteria"
        Me.btnResetCriteria_Criteria.Size = New System.Drawing.Size(96, 23)
        Me.btnResetCriteria_Criteria.TabIndex = 10
        Me.btnResetCriteria_Criteria.Text = "Reset"
        Me.btnResetCriteria_Criteria.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.nudMax_Criteria)
        Me.GroupBox3.Controls.Add(Me.txtDefault_Criteria)
        Me.GroupBox3.Controls.Add(Me.nudDefault_Criteria)
        Me.GroupBox3.Controls.Add(Me.chkDefault_Criteria)
        Me.GroupBox3.Controls.Add(Me.cboDefault_Criteria)
        Me.GroupBox3.Controls.Add(Me.Label23)
        Me.GroupBox3.Controls.Add(Me.nudId_Criteria)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.cboDataType_Criteria)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.txtCriteriaName_Criteria)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Location = New System.Drawing.Point(257, 233)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(232, 162)
        Me.GroupBox3.TabIndex = 13
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Edit Criteria"
        '
        'nudMax_Criteria
        '
        Me.nudMax_Criteria.Location = New System.Drawing.Point(91, 100)
        Me.nudMax_Criteria.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.nudMax_Criteria.Name = "nudMax_Criteria"
        Me.nudMax_Criteria.Size = New System.Drawing.Size(120, 20)
        Me.nudMax_Criteria.TabIndex = 14
        '
        'txtDefault_Criteria
        '
        Me.txtDefault_Criteria.Location = New System.Drawing.Point(91, 127)
        Me.txtDefault_Criteria.MaxLength = 30
        Me.txtDefault_Criteria.Multiline = True
        Me.txtDefault_Criteria.Name = "txtDefault_Criteria"
        Me.txtDefault_Criteria.Size = New System.Drawing.Size(134, 20)
        Me.txtDefault_Criteria.TabIndex = 13
        '
        'nudDefault_Criteria
        '
        Me.nudDefault_Criteria.Location = New System.Drawing.Point(91, 126)
        Me.nudDefault_Criteria.Name = "nudDefault_Criteria"
        Me.nudDefault_Criteria.Size = New System.Drawing.Size(64, 20)
        Me.nudDefault_Criteria.TabIndex = 12
        '
        'chkDefault_Criteria
        '
        Me.chkDefault_Criteria.AutoSize = True
        Me.chkDefault_Criteria.Location = New System.Drawing.Point(91, 128)
        Me.chkDefault_Criteria.Name = "chkDefault_Criteria"
        Me.chkDefault_Criteria.Size = New System.Drawing.Size(15, 14)
        Me.chkDefault_Criteria.TabIndex = 11
        Me.chkDefault_Criteria.UseVisualStyleBackColor = True
        '
        'cboDefault_Criteria
        '
        Me.cboDefault_Criteria.FormattingEnabled = True
        Me.cboDefault_Criteria.Location = New System.Drawing.Point(91, 126)
        Me.cboDefault_Criteria.Name = "cboDefault_Criteria"
        Me.cboDefault_Criteria.Size = New System.Drawing.Size(134, 21)
        Me.cboDefault_Criteria.TabIndex = 10
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(6, 128)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(71, 13)
        Me.Label23.TabIndex = 9
        Me.Label23.Text = "Default Value"
        '
        'nudId_Criteria
        '
        Me.nudId_Criteria.Location = New System.Drawing.Point(91, 22)
        Me.nudId_Criteria.Name = "nudId_Criteria"
        Me.nudId_Criteria.Size = New System.Drawing.Size(63, 20)
        Me.nudId_Criteria.TabIndex = 8
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(6, 102)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(56, 13)
        Me.Label22.TabIndex = 6
        Me.Label22.Text = "Max value"
        '
        'cboDataType_Criteria
        '
        Me.cboDataType_Criteria.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDataType_Criteria.FormattingEnabled = True
        Me.cboDataType_Criteria.Location = New System.Drawing.Point(91, 72)
        Me.cboDataType_Criteria.Name = "cboDataType_Criteria"
        Me.cboDataType_Criteria.Size = New System.Drawing.Size(134, 21)
        Me.cboDataType_Criteria.TabIndex = 5
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(6, 75)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(53, 13)
        Me.Label16.TabIndex = 4
        Me.Label16.Text = "Data type"
        '
        'txtCriteriaName_Criteria
        '
        Me.txtCriteriaName_Criteria.Location = New System.Drawing.Point(91, 46)
        Me.txtCriteriaName_Criteria.MaxLength = 30
        Me.txtCriteriaName_Criteria.Name = "txtCriteriaName_Criteria"
        Me.txtCriteriaName_Criteria.Size = New System.Drawing.Size(134, 20)
        Me.txtCriteriaName_Criteria.TabIndex = 3
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(6, 49)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(35, 13)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Name"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 24)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(16, 13)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Id"
        '
        'btnDeleteCriteria_Criteria
        '
        Me.btnDeleteCriteria_Criteria.Location = New System.Drawing.Point(66, 401)
        Me.btnDeleteCriteria_Criteria.Name = "btnDeleteCriteria_Criteria"
        Me.btnDeleteCriteria_Criteria.Size = New System.Drawing.Size(50, 23)
        Me.btnDeleteCriteria_Criteria.TabIndex = 9
        Me.btnDeleteCriteria_Criteria.Text = "Delete"
        Me.btnDeleteCriteria_Criteria.UseVisualStyleBackColor = True
        '
        'btnSave_Criteria
        '
        Me.btnSave_Criteria.Location = New System.Drawing.Point(257, 401)
        Me.btnSave_Criteria.Name = "btnSave_Criteria"
        Me.btnSave_Criteria.Size = New System.Drawing.Size(77, 23)
        Me.btnSave_Criteria.TabIndex = 6
        Me.btnSave_Criteria.Text = "Save"
        Me.btnSave_Criteria.UseVisualStyleBackColor = True
        '
        'btnAddCriteria_Criteria
        '
        Me.btnAddCriteria_Criteria.Location = New System.Drawing.Point(7, 401)
        Me.btnAddCriteria_Criteria.Name = "btnAddCriteria_Criteria"
        Me.btnAddCriteria_Criteria.Size = New System.Drawing.Size(53, 23)
        Me.btnAddCriteria_Criteria.TabIndex = 8
        Me.btnAddCriteria_Criteria.Text = "New"
        Me.btnAddCriteria_Criteria.UseVisualStyleBackColor = True
        '
        'txtProfileName_Criteria
        '
        Me.txtProfileName_Criteria.Location = New System.Drawing.Point(7, 224)
        Me.txtProfileName_Criteria.Name = "txtProfileName_Criteria"
        Me.txtProfileName_Criteria.Size = New System.Drawing.Size(232, 20)
        Me.txtProfileName_Criteria.TabIndex = 5
        '
        'btnNewProfile_Criteria
        '
        Me.btnNewProfile_Criteria.Location = New System.Drawing.Point(7, 183)
        Me.btnNewProfile_Criteria.Name = "btnNewProfile_Criteria"
        Me.btnNewProfile_Criteria.Size = New System.Drawing.Size(44, 23)
        Me.btnNewProfile_Criteria.TabIndex = 4
        Me.btnNewProfile_Criteria.Text = "New"
        Me.btnNewProfile_Criteria.UseVisualStyleBackColor = True
        '
        'btnDeleteProfile_Criteria
        '
        Me.btnDeleteProfile_Criteria.Location = New System.Drawing.Point(57, 183)
        Me.btnDeleteProfile_Criteria.Name = "btnDeleteProfile_Criteria"
        Me.btnDeleteProfile_Criteria.Size = New System.Drawing.Size(50, 23)
        Me.btnDeleteProfile_Criteria.TabIndex = 2
        Me.btnDeleteProfile_Criteria.Text = "Delete"
        Me.btnDeleteProfile_Criteria.UseVisualStyleBackColor = True
        '
        'lstProfiles_Criteria
        '
        Me.lstProfiles_Criteria.FormattingEnabled = True
        Me.lstProfiles_Criteria.Location = New System.Drawing.Point(7, 43)
        Me.lstProfiles_Criteria.Name = "lstProfiles_Criteria"
        Me.lstProfiles_Criteria.Size = New System.Drawing.Size(232, 134)
        Me.lstProfiles_Criteria.TabIndex = 1
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(4, 26)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(41, 13)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Profiles"
        '
        'tabReport
        '
        Me.tabReport.Controls.Add(Me.GroupBox7)
        Me.tabReport.Controls.Add(Me.GroupBox6)
        Me.tabReport.Location = New System.Drawing.Point(4, 22)
        Me.tabReport.Name = "tabReport"
        Me.tabReport.Size = New System.Drawing.Size(914, 601)
        Me.tabReport.TabIndex = 3
        Me.tabReport.Text = "Generate Report"
        Me.tabReport.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.btnExportSpreadsheet_GenerateReport)
        Me.GroupBox7.Controls.Add(Me.cboTerm_GenerateReport)
        Me.GroupBox7.Controls.Add(Me.Label2)
        Me.GroupBox7.Controls.Add(Me.Label18)
        Me.GroupBox7.Controls.Add(Me.lstStudents_GenerateReport)
        Me.GroupBox7.Controls.Add(Me.btnGenerateReport)
        Me.GroupBox7.Controls.Add(Me.Label20)
        Me.GroupBox7.Controls.Add(Me.cboClass_GenerateReport)
        Me.GroupBox7.Location = New System.Drawing.Point(15, 16)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(720, 210)
        Me.GroupBox7.TabIndex = 14
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Create Progress Report"
        '
        'btnExportSpreadsheet_GenerateReport
        '
        Me.btnExportSpreadsheet_GenerateReport.Location = New System.Drawing.Point(565, 79)
        Me.btnExportSpreadsheet_GenerateReport.Name = "btnExportSpreadsheet_GenerateReport"
        Me.btnExportSpreadsheet_GenerateReport.Size = New System.Drawing.Size(111, 41)
        Me.btnExportSpreadsheet_GenerateReport.TabIndex = 14
        Me.btnExportSpreadsheet_GenerateReport.Text = "Export progress spreadsheet"
        Me.btnExportSpreadsheet_GenerateReport.UseVisualStyleBackColor = True
        '
        'cboTerm_GenerateReport
        '
        Me.cboTerm_GenerateReport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTerm_GenerateReport.FormattingEnabled = True
        Me.cboTerm_GenerateReport.Location = New System.Drawing.Point(14, 142)
        Me.cboTerm_GenerateReport.Name = "cboTerm_GenerateReport"
        Me.cboTerm_GenerateReport.Size = New System.Drawing.Size(121, 21)
        Me.cboTerm_GenerateReport.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(173, 126)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Select A Class"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(373, 26)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(85, 13)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Select A student"
        '
        'lstStudents_GenerateReport
        '
        Me.lstStudents_GenerateReport.FormattingEnabled = True
        Me.lstStudents_GenerateReport.Location = New System.Drawing.Point(376, 42)
        Me.lstStudents_GenerateReport.Name = "lstStudents_GenerateReport"
        Me.lstStudents_GenerateReport.Size = New System.Drawing.Size(172, 121)
        Me.lstStudents_GenerateReport.TabIndex = 1
        '
        'btnGenerateReport
        '
        Me.btnGenerateReport.Location = New System.Drawing.Point(565, 126)
        Me.btnGenerateReport.Name = "btnGenerateReport"
        Me.btnGenerateReport.Size = New System.Drawing.Size(111, 39)
        Me.btnGenerateReport.TabIndex = 12
        Me.btnGenerateReport.Text = "Generate Report"
        Me.btnGenerateReport.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(11, 126)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(74, 13)
        Me.Label20.TabIndex = 4
        Me.Label20.Text = "Select A Term"
        '
        'cboClass_GenerateReport
        '
        Me.cboClass_GenerateReport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboClass_GenerateReport.FormattingEnabled = True
        Me.cboClass_GenerateReport.Location = New System.Drawing.Point(174, 142)
        Me.cboClass_GenerateReport.Name = "cboClass_GenerateReport"
        Me.cboClass_GenerateReport.Size = New System.Drawing.Size(169, 21)
        Me.cboClass_GenerateReport.TabIndex = 9
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.lblTotalSessions_GenerateReport)
        Me.GroupBox6.Controls.Add(Me.Label27)
        Me.GroupBox6.Controls.Add(Me.lblTotalAttended_GenerateReport)
        Me.GroupBox6.Controls.Add(Me.Label24)
        Me.GroupBox6.Controls.Add(Me.lblAttendance_GenerateReport)
        Me.GroupBox6.Controls.Add(Me.lblProgressTitle_GenerateReport)
        Me.GroupBox6.Controls.Add(Me.label123)
        Me.GroupBox6.Location = New System.Drawing.Point(15, 234)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(720, 353)
        Me.GroupBox6.TabIndex = 11
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Progress report"
        '
        'lblTotalSessions_GenerateReport
        '
        Me.lblTotalSessions_GenerateReport.AutoSize = True
        Me.lblTotalSessions_GenerateReport.Location = New System.Drawing.Point(141, 74)
        Me.lblTotalSessions_GenerateReport.Name = "lblTotalSessions_GenerateReport"
        Me.lblTotalSessions_GenerateReport.Size = New System.Drawing.Size(13, 13)
        Me.lblTotalSessions_GenerateReport.TabIndex = 16
        Me.lblTotalSessions_GenerateReport.Text = "--"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(18, 100)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(122, 13)
        Me.Label27.TabIndex = 15
        Me.Label27.Text = "Total sessions attended:"
        '
        'lblTotalAttended_GenerateReport
        '
        Me.lblTotalAttended_GenerateReport.AutoSize = True
        Me.lblTotalAttended_GenerateReport.Location = New System.Drawing.Point(141, 100)
        Me.lblTotalAttended_GenerateReport.Name = "lblTotalAttended_GenerateReport"
        Me.lblTotalAttended_GenerateReport.Size = New System.Drawing.Size(13, 13)
        Me.lblTotalAttended_GenerateReport.TabIndex = 14
        Me.lblTotalAttended_GenerateReport.Text = "--"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(21, 125)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(65, 13)
        Me.Label24.TabIndex = 13
        Me.Label24.Text = "Attendance:"
        '
        'lblAttendance_GenerateReport
        '
        Me.lblAttendance_GenerateReport.AutoSize = True
        Me.lblAttendance_GenerateReport.Location = New System.Drawing.Point(141, 125)
        Me.lblAttendance_GenerateReport.Name = "lblAttendance_GenerateReport"
        Me.lblAttendance_GenerateReport.Size = New System.Drawing.Size(13, 13)
        Me.lblAttendance_GenerateReport.TabIndex = 12
        Me.lblAttendance_GenerateReport.Text = "--"
        '
        'lblProgressTitle_GenerateReport
        '
        Me.lblProgressTitle_GenerateReport.AutoSize = True
        Me.lblProgressTitle_GenerateReport.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProgressTitle_GenerateReport.Location = New System.Drawing.Point(16, 28)
        Me.lblProgressTitle_GenerateReport.Name = "lblProgressTitle_GenerateReport"
        Me.lblProgressTitle_GenerateReport.Size = New System.Drawing.Size(110, 20)
        Me.lblProgressTitle_GenerateReport.TabIndex = 11
        Me.lblProgressTitle_GenerateReport.Text = "Student, Term"
        '
        'label123
        '
        Me.label123.AutoSize = True
        Me.label123.Location = New System.Drawing.Point(21, 74)
        Me.label123.Name = "label123"
        Me.label123.Size = New System.Drawing.Size(119, 13)
        Me.label123.TabIndex = 10
        Me.label123.Text = "Total sessions this term:"
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(945, 651)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "Main"
        Me.Text = "P.E helper app"
        Me.TabControl1.ResumeLayout(False)
        Me.tabClassMarking.ResumeLayout(False)
        Me.tabClassMarking.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.tabStudents.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.imgIcon_Students, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.nudClassId_Students, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabLessonProfiles.ResumeLayout(False)
        Me.tabLessonProfiles.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.nudMax_Criteria, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudDefault_Criteria, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudId_Criteria, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabReport.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents tabClassMarking As TabPage
    Friend WithEvents tabStudents As TabPage
    Friend WithEvents tabLessonProfiles As TabPage
    Friend WithEvents tabReport As TabPage
    Friend WithEvents cboPeriodSearch_ClassMarking As ComboBox
    Friend WithEvents lstClassEntries_ClassMarking As ListBox
    Friend WithEvents cboClassSearch_ClassMarking As ComboBox
    Friend WithEvents cboTermSearch_ClassMarking As ComboBox
    Friend WithEvents cboYearSearch_ClassMarking As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnEdit_ClassMarking As Button
    Friend WithEvents btnDelete_ClassMarking As Button
    Friend WithEvents btnNew_Students As Button
    Friend WithEvents btnDeleteStudent_Students As Button
    Friend WithEvents lstStudents_Students As ListBox
    Friend WithEvents Label10 As Label
    Friend WithEvents lblGender_Students As Label
    Friend WithEvents lblAge_Students As Label
    Friend WithEvents lblName_Students As Label
    Friend WithEvents lstStudentClasses_Students As ListBox
    Friend WithEvents txtComment_Students As TextBox
    Friend WithEvents imgIcon_Students As PictureBox
    Friend WithEvents btnSaveClass_Students As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents txtClassYear_Students As TextBox
    Friend WithEvents txtClassName_Students As TextBox
    Friend WithEvents btnDeleteClass_Students As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents lstClasses_Students As ListBox
    Friend WithEvents btnLoadList_Students As Button
    Friend WithEvents btnEdit_Students As Button
    Friend WithEvents btnNewProfile_Criteria As Button
    Friend WithEvents btnDeleteProfile_Criteria As Button
    Friend WithEvents lstProfiles_Criteria As ListBox
    Friend WithEvents Label17 As Label
    Friend WithEvents btnResetCriteria_Criteria As Button
    Friend WithEvents btnDeleteCriteria_Criteria As Button
    Friend WithEvents btnAddCriteria_Criteria As Button
    Friend WithEvents btnSave_Criteria As Button
    Friend WithEvents txtProfileName_Criteria As TextBox
    Friend WithEvents cboTerm_GenerateReport As ComboBox
    Friend WithEvents Label20 As Label
    Friend WithEvents lstStudents_GenerateReport As ListBox
    Friend WithEvents Label18 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnNewClass_Students As Button
    Friend WithEvents nudClassId_Students As NumericUpDown
    Friend WithEvents label21 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents lstCriteria_Criteria As ListBox
    Friend WithEvents txtCriteriaName_Criteria As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents cboDataType_Criteria As ComboBox
    Friend WithEvents Label16 As Label
    Friend WithEvents cboDefault_Criteria As ComboBox
    Friend WithEvents Label23 As Label
    Friend WithEvents nudId_Criteria As NumericUpDown
    Friend WithEvents Label22 As Label
    Friend WithEvents chkDefault_Criteria As CheckBox
    Friend WithEvents nudDefault_Criteria As NumericUpDown
    Friend WithEvents txtDefault_Criteria As TextBox
    Friend WithEvents btnMarkClass_ClassMarking As Button
    Friend WithEvents nudMax_Criteria As NumericUpDown
    Friend WithEvents lblClassFilter As Label
    Friend WithEvents btnDeselect_Students As Button
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lblAttendance_ClassMarking As Label
    Friend WithEvents lblStudentsMarked_CLassMarking As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents lblClass_ClassMarking As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblProfile_ClassMarking As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents lblDate_ClassMarking As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents lblPeriod_ClassMarking As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents cboClass_GenerateReport As ComboBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents label123 As Label
    Friend WithEvents lblProgressTitle_GenerateReport As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnGenerateReport As Button
    Friend WithEvents lblAttendance_GenerateReport As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents lblTotalAttended_GenerateReport As Label
    Friend WithEvents lblTotalSessions_GenerateReport As Label
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents btnExportSpreadsheet_GenerateReport As Button
    Friend WithEvents sfdSaveFile As SaveFileDialog
End Class
