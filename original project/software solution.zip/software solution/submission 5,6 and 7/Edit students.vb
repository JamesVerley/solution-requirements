﻿' last edited 17/08/17
' displays a form which the user can fill out to manually save and edit student records

Public Class Edit_students

    ' index of students, not Student.id (students(studentListIndex).id -> Student.id)
    Public studentListIndex
    Public item

    ' the user has selected a student and clicked edit. this sub displays the selected student details
    Public Sub EditStudent(id As Integer)
        studentListIndex = id ' 
        'If BinarySearchID(students, maxStudent, id) <> -1 Then
        updateClasses()

        ' load properties of student being edited into form controls
        With students(studentListIndex)
            txtFname.Text = .fname
            txtLname.Text = .lname
            txtNotes.Text = .comment

            imgIcon.ImageLocation = inputFolder & "student icons/" & .id & ".png"
            If .gender = 0 Then
                rdoMale.Select()
            Else
                rdoFemale.Select()
            End If

            cboClass.Text = classRecords(.classId).name

            dtpBirthDate.Value = .birthdate
            Try
                cboClass.SelectedIndex = .classId
            Catch ex As Exception
                cboClass.SelectedIndex = 0
            End Try
        End With
    End Sub

    ' clear the form and prepare to generate a new student record
    Public Sub NewStudent()
        studentListIndex = maxStudent + 1
        Clear()
        updateClasses()
        rdoMale.Select()
    End Sub

    ' refresh items in the class combobox
    Private Sub updateClasses()
        cboClass.Items.Clear()
        For i = 0 To maxClassRecord
            With classRecords(i)
                cboClass.Items.Add(.name)
            End With
        Next
    End Sub

    Private Sub btnChangeIcon_Click(sender As Object, e As EventArgs) Handles btnChangeIcon.Click
        'the filename (will show in the filename box)
        ofdIcon.FileName = ""
        'the title of the window to open a file
        ofdIcon.Title = "Open File..."
        'the filetypes to allow the user to view
        ofdIcon.Filter = "IMAGE FILES|*.png;*.jpg;*.jpeg"
        'now to open the dialogue and check if OK has been pressed
        If ofdIcon.ShowDialog = DialogResult.OK Then
            imgIcon.ImageLocation = ofdIcon.FileName
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        ' validation, make sure a valid name and class has been entered
        If txtFname.Text.Length < 2 Or txtLname.Text.Length < 2 Then
            MessageBox.Show("Please enter a valid name")
            Return
        End If
        If txtFname.Text.Length < 2 Then
            MessageBox.Show("Please enter a valid first name")
            Return
        End If
        If cboClass.SelectedIndex = -1 Then
            MessageBox.Show("Please select a class")
            Return
        End If
        If imgIcon.ImageLocation <> (inputFolder & "icons/default.png") Then
            imgIcon.Image.Save(inputFolder & "student icons/" & studentListIndex & ".png")
        End If

        ' save all student properties to relevant index of students list
        With students(studentListIndex)
            .id = studentListIndex
            .fname = txtFname.Text
            .lname = txtLname.Text
            .gender = -rdoFemale.Checked
            .birthdate = dtpBirthDate.Value
            .classId = classRecords(cboClass.SelectedIndex).id
            .comment = txtNotes.Text
            If studentListIndex > maxStudent Then
                maxStudent += 1
                Main.lstStudents_Students.SelectedIndex = Main.lstStudents_Students.Items.Count - 1
            Else
            End If
        End With
        ' refresh students throughout main form and close this form
        Main.UpdateStudents()
        Close()
    End Sub

    ' reset the values of all controls of the form to their defaults
    Public Sub Clear()
        txtFname.Text = ""
        txtLname.Text = ""
        txtNotes.Text = ""

        imgIcon.ImageLocation = inputFolder & "student icons/default.png"
        rdoMale.Select()
        Dim d As Date = Date.Now
        d = CDate("06 06 " & (d.Year - 12))
        dtpBirthDate.Value = d
    End Sub
End Class