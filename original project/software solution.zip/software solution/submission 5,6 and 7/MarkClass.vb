﻿' last edited 17/08/17
' James Verley 2017 term 3 software development sat solution

' this Class allows teachers to mark or edit marks for any class on any list of criteria using an interface with
' many features to help them swiftly record student performance.

Public Class Mark_Class
    Public entryIndex As Integer
    Private lstStudentIndices(999) As Integer
    Private tempClassMarking As ClassMarking
    Private selectedClass As Integer
    Public selectedCriteria As Integer = 0
    Public selectedProfile As Integer = 0

    ' fill out controls based on properties of entry being edited
    Public Sub EditEntry(index As Integer)
        entryIndex = index
        tempClassMarking = classMarkings(entryIndex)
        With tempClassMarking
            ' display details of marking entry in nearby controls
            cboProfile.SelectedIndex = BinarySearchID(profiles, maxProfile, .profileId)
            cboClass.SelectedIndex = BinarySearchID(classRecords, maxClassRecord, .classId)
            cboPeriod.SelectedIndex = .periodId
            txtComment.Text = .comment
        End With
        selectedCriteria = 0
        updateStudents()
        lstStudents.SelectedIndex = 0
    End Sub

    ' reset all controls and clear all old student marks
    Public Sub NewEntry()
        cboProfile.SelectedIndex = 0
        cboClass.SelectedIndex = 0
        txtComment.Text = ""

        entryIndex = maxClassMarking + 1
        tempClassMarking = New ClassMarking()
        selectedCriteria = 0
        updateStudents()
        lstStudents.SelectedIndex = 0
    End Sub

    ' when a new student is selected, display their info and mark
    Private Sub lstStudents_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstStudents.SelectedIndexChanged
        If lstStudents.SelectedIndex <> -1 Then
            With globals.students(lstStudentIndices(lstStudents.SelectedIndex))
                imgStudent.ImageLocation = inputFolder & "/student icons/" & .id & ".png"
                lblFname.Text = .fname & " " & .lname
            End With
            DisplayStudentMarks()
        End If
    End Sub

    ' update name of criteria displayed, show relevant control to datatype and hide the rest
    Private Sub UpdateCriteria()
        If selectedCriteria <> -1 And cboProfile.SelectedIndex <> -1 Then
            With profiles(cboProfile.SelectedIndex).criteria(selectedCriteria)
                lblCriteria.Text = .name
            End With
            txtTextEntry.Hide()
            chkCheckEntry.Hide()
            nudNumber.Hide()
            nudNumerator.Hide()
            lblDiv.Hide()
            txtMaxNum.Hide()
            Select Case profiles(cboProfile.SelectedIndex).criteria(selectedCriteria).typeId
                Case 0 ' checkbox
                    chkCheckEntry.Show()
                Case 1 ' number
                    nudNumber.Show()
                Case 2 ' fraction
                    nudNumerator.Show()
                    txtMaxNum.Show()
                    lblDiv.Show()
                Case 3 ' text
                    txtTextEntry.Show()
            End Select
        End If
    End Sub

    ' change criteria and therefore marking datatype based on new profile selected
    Private Sub cboProfile_SelectedIndexChanged() Handles cboProfile.SelectedIndexChanged
        selectedProfile = cboProfile.SelectedIndex
        If selectedProfile <> -1 Then
            tempClassMarking.profileId = profiles(cboProfile.SelectedIndex).id

            ' update title based on selected classrecord and profile
            lblMarkTitle.Text = classRecords(
                BinarySearchID(classRecords,
                                    maxClassRecord,
                                    tempClassMarking.classId)).name &
                                    " " & profiles(
                                    BinarySearchID(profiles, maxProfile,
                                    tempClassMarking.profileId)).name
        End If
    End Sub

    Private Sub updateStudents() ' fill the listbox with student names
        lstStudents.Items.Clear()
        Dim increment As Integer = 0
        For item = 0 To maxStudent
            If globals.students(item).classId = classRecords(selectedClass).id Then
                lstStudents.Items.Add(globals.students(item).fname & " " & globals.students(item).lname)
                lstStudentIndices(increment) = item
                increment += 1
            End If
        Next
        UpdateCriteria()
    End Sub

    ' prompt the user for confirmation, then update student list of records
    Private Sub cboClass_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboClass.SelectionChangeCommitted
        If MessageBox.Show("are you sure you want to change class and discard temporary recorded data?", "Reset data", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            selectedClass = cboClass.SelectedIndex
            tempClassMarking.classId = classRecords(cboClass.SelectedIndex).id
            ' reset all mark values of studentMarkEntries
            Dim temp(999) As StudentMarkEntry
            tempClassMarking.studentMarkEntries = temp
            cboProfile_SelectedIndexChanged()
            updateStudents()
        Else
            cboClass.SelectedIndex = selectedClass
        End If
    End Sub

    ' save temporary class marking to the actual list of class markings
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        tempClassMarking.comment = txtComment.Text
        tempClassMarking.entryDate = dtpDate.Value
        If entryIndex > maxClassMarking Then
            maxClassMarking += 1
        End If
        classMarkings(entryIndex) = tempClassMarking
        Main.UpdateEntries()
        Close()
    End Sub

    Public Sub DisplayStudentMarks()
        If lstStudents.SelectedIndex <> -1 And cboProfile.SelectedIndex <> -1 Then
            With tempClassMarking
                Dim StudentMarkEntryIndex As Integer = -1
                Dim markDataIndex As Integer = -1
                Dim tempValue As String
                ' get studentMarkEntry index based on student id
                For i = 0 To .maxStudentMarkEntry
                    Try
                        If .studentMarkEntries(i).studentId = globals.students(lstStudentIndices(lstStudents.SelectedIndex)).id Then
                            StudentMarkEntryIndex = i
                        End If
                    Catch
                    End Try
                Next

                If StudentMarkEntryIndex <> -1 Then
                    ' find markData index based on criteriaId
                    For i = 0 To .studentMarkEntries(StudentMarkEntryIndex).maxMarkData
                        Try
                            If .studentMarkEntries(StudentMarkEntryIndex).markData(i).criteriaId = profiles(selectedProfile).criteria(selectedCriteria).id Then
                                markDataIndex = i
                            End If
                        Catch
                        End Try
                    Next

                    ' if these records could not be found, display default records
                    If markDataIndex = -1 Then
                        lblMarked.Text = "Unmarked"
                        tempValue = profiles(selectedProfile).criteria(selectedCriteria).defaultValue
                    Else
                        lblMarked.Text = "Marked"
                        tempValue = tempClassMarking.studentMarkEntries(StudentMarkEntryIndex).markData(markDataIndex).data
                    End If
                    ' .studentMarkEntries(StudentMarkEntryIndex).markData(markDataIndex)
                Else
                    lblMarked.Text = "Unmarked"
                    tempValue = profiles(selectedProfile).criteria(selectedCriteria).defaultValue
                End If

                ' display mark to relevant control
                Select Case profiles(selectedProfile).criteria(selectedCriteria).typeId
                    Case 0 ' checkbox
                        chkCheckEntry.Checked = CBool(tempValue)
                    Case 1 ' number
                        nudNumber.Value = CInt(tempValue)
                    Case 2 ' fraction
                        nudNumerator.Value = CInt(tempValue)
                        txtMaxNum.Text = profiles(selectedProfile).criteria(selectedCriteria).max
                        lblDiv.Show()
                    Case 3 ' text
                        txtTextEntry.Show()
                End Select

            End With
        End If
    End Sub

    Private Sub SaveCurrentMark()
        ' to save a class marking record
        If lstStudents.SelectedIndex <> -1 And cboProfile.SelectedIndex <> -1 Then
            Dim tempMarkEntry As Integer = -1
            Dim tempMarkData As Integer = -1
            Dim selectedStudent As Integer = lstStudentIndices(lstStudents.SelectedIndex)

            With tempClassMarking
                If Not IsNothing(.studentMarkEntries) Then
                    ' search for the correct .studentMarkEntries(?) by finding a match for studentId
                    ' get studentMarkEntry index based on student id
                    For i = 0 To .maxStudentMarkEntry
                        If .studentMarkEntries(i).studentId = globals.students(selectedStudent).id Then
                            tempMarkEntry = i
                        End If
                    Next
                Else
                    ' .studentMarkEntries doesn't exist, so it needs to be dimensioned
                    ReDim .studentMarkEntries(99)
                    .maxStudentMarkEntry = -1
                End If

                ' if no match can be found, create a new .studentMarkEntries(maxStudentMarkEntry) and .markData(maxMarkData)
                If tempMarkEntry = -1 Then
                    .maxStudentMarkEntry += 1
                    tempMarkEntry = .maxStudentMarkEntry
                    ReDim .studentMarkEntries(tempMarkEntry).markData(30)
                    .studentMarkEntries(tempMarkEntry).studentId = globals.students(selectedStudent).id
                    .studentMarkEntries(tempMarkEntry).maxMarkData = -1
                    .studentMarkEntries(tempMarkEntry).markData(0).criteriaId = profiles(selectedProfile).criteria(selectedCriteria).id
                    tempMarkData = 0
                Else
                    ' then search for the correct .studentMarkEntries(index).markData(?) by finding a match for criteriaId
                    ' find markData index based on criteriaId
                    For i = 0 To .studentMarkEntries(tempMarkEntry).maxMarkData
                        Try
                            If .studentMarkEntries(tempMarkEntry).markData(i).criteriaId = profiles(selectedProfile).criteria(selectedCriteria).id Then
                                tempMarkData = i
                            End If
                        Catch
                        End Try
                    Next

                    ' if no match is found for .markdata(?).criteriaId or there was no studentMarkEntry inthefirstplace, create a new .markData(maxMarkData) record
                    If tempMarkData = -1 Then
                        .studentMarkEntries(tempMarkEntry).maxMarkData += 1
                        ' dimension the markdata of new max record
                        If IsNothing(.studentMarkEntries(tempMarkEntry).markData) Then
                            ReDim .studentMarkEntries(tempMarkEntry).markData(30)
                        End If

                        .studentMarkEntries(tempMarkEntry).markData(.studentMarkEntries(tempMarkEntry).maxMarkData).criteriaId = profiles(selectedProfile).criteria(selectedCriteria).id
                        .studentMarkEntries(tempMarkEntry).markData(.studentMarkEntries(tempMarkEntry).maxMarkData).data = ""
                        tempMarkData = .studentMarkEntries(tempMarkEntry).maxMarkData
                    End If

                    ' this is just a selection sort function for sorting student marks by criteriaId
                    Dim ii As Integer
                    Dim smallest As Integer
                    Dim tempRecord
                    For i = 0 To .studentMarkEntries(tempMarkEntry).maxMarkData
                        smallest = i
                        For ii = i To .studentMarkEntries(tempMarkEntry).maxMarkData
                            If .studentMarkEntries(tempMarkEntry).markData(ii).criteriaId < .studentMarkEntries(tempMarkEntry).markData(i).criteriaId Then
                                smallest = ii
                            End If
                        Next
                        tempRecord = .studentMarkEntries(tempMarkEntry).markData(i)
                        .studentMarkEntries(tempMarkEntry).markData(i) = .studentMarkEntries(tempMarkEntry).markData(smallest)
                        tempClassMarking.studentMarkEntries(tempMarkEntry).markData(smallest) = tempRecord
                    Next
                End If

                ' finally, save data from the right control into the .markdata.data variable
                With tempClassMarking.studentMarkEntries(tempMarkEntry).markData(tempMarkData)
                    Select Case profiles(selectedProfile).criteria(selectedCriteria).typeId
                        Case 0
                            .data = CStr(chkCheckEntry.Checked) ' tickbox
                        Case 1
                            .data = CStr(nudNumber.Value) ' number
                        Case 2
                            .data = CStr(nudNumerator.Value) ' fraction
                        Case 3
                            .data = txtTextEntry.Text ' string
                    End Select
                End With
            End With
        End If
    End Sub

    ' save, decrement student or criteria then update, depending on the user option
    Private Sub BtnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        SaveCurrentMark() ' save mark before changing scope
        If chkIncrementStudent.Checked Then ' if incrementing by students
            If lstStudents.SelectedIndex = 0 Then
                If selectedCriteria <> 0 Then
                    selectedCriteria -= 1 ' increment criteria
                    lstStudents.SelectedIndex = lstStudents.Items.Count - 1 ' loop selected student to last one
                    UpdateCriteria()
                End If
            Else
                lstStudents.SelectedIndex -= 1
            End If
        Else ' if incrementing by criteria
            If selectedCriteria = 0 Then
                ' increment students
                If lstStudents.SelectedIndex <> 0 Then
                    selectedCriteria = profiles(selectedProfile).maxCriteria
                    UpdateCriteria()
                    lstStudents.SelectedIndex -= 1
                End If
            Else
                selectedCriteria -= 1
                UpdateCriteria()
            End If
        End If
        DisplayStudentMarks()
    End Sub

    ' save, decrement student or criteria then update, depending on the user option
    Private Sub BtnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        SaveCurrentMark() ' save mark before changing scope
        If chkIncrementStudent.Checked Then ' if incrementing by student
            If lstStudents.SelectedIndex = lstStudents.Items.Count - 1 Then
                If selectedCriteria <> profiles(selectedProfile).maxCriteria Then
                    selectedCriteria += 1 ' increment criteria
                    lstStudents.SelectedIndex = 0 ' loop selected student to first one
                    UpdateCriteria()
                End If
            Else
                lstStudents.SelectedIndex += 1
            End If
        Else ' if incrementing by criteria
            If selectedCriteria = profiles(selectedProfile).maxCriteria Then
                ' increment students
                If lstStudents.SelectedIndex <> lstStudents.Items.Count - 1 Then
                    selectedCriteria = profiles(selectedProfile).maxCriteria
                    UpdateCriteria()
                    lstStudents.SelectedIndex += 1
                End If
            Else
                selectedCriteria += 1
                UpdateCriteria()
            End If
        End If
        DisplayStudentMarks()
    End Sub

    ' if not at the end, save mark, increment criteria then update display
    Private Sub btnCriteriaLeft_Click(sender As Object, e As EventArgs) Handles btnCriteriaLeft.Click
        If selectedCriteria > 0 Then
            SaveCurrentMark()
            selectedCriteria -= 1
            UpdateCriteria()
            DisplayStudentMarks()
        End If

    End Sub

    ' if not at the start, save mark, decrement criteria then update display
    Private Sub btnCriteriaRight_Click(sender As Object, e As EventArgs) Handles btnCriteriaRight.Click
        If selectedCriteria < profiles(cboProfile.SelectedIndex).maxCriteria Then
            SaveCurrentMark()
            selectedCriteria += 1
            UpdateCriteria()
            DisplayStudentMarks()
        End If
    End Sub
End Class